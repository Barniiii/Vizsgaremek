import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  // Állapotok definiálása
  const [mobileMenuActive, setMobileMenuActive] = useState(false);
  const [headerShadow, setHeaderShadow] = useState('var(--shadow-light)');

  // Mobil menü váltása
  const toggleMobileMenu = () => {
    setMobileMenuActive(!mobileMenuActive);
  };

  // Menü bezárása
  const closeMobileMenu = () => {
    setMobileMenuActive(false);
  };

  // Görgetés hatása a fejlécre
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setHeaderShadow('0 4px 12px rgba(0, 0, 0, 0.1)');
      } else {
        setHeaderShadow('var(--shadow-light)');
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Gördülési animációk
  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, observerOptions);

    // Animálandó elemek
    const animateElements = document.querySelectorAll('.feature-card, .benefit-list li, .auth-container');
    animateElements.forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      observer.observe(el);
    });

    return () => {
      animateElements.forEach(el => observer.unobserve(el));
    };
  }, []);

  // Bejelentkezési űrlap kezelése
  const handleLoginSubmit = (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;
    
    // Itt lenne a tényleges bejelentkezési logika
    alert(`Bejelentkezési kísérlet e-mail címmel: ${email}\n(Egy valós alkalmazásban itt történne a hitelesítés.)`);
  };

  return (
    <div className="App">
      {/* FELSŐ NAVIGÁCIÓ */}
      <header style={{ boxShadow: headerShadow }}>
        <div className="container header-container">
          <a href="#" className="logo">
            <i className="fas fa-seedling logo-icon"></i>
            <span>BB Agrár</span>
          </a>
          
          <button className="mobile-menu-btn" onClick={toggleMobileMenu}>
            <i className={mobileMenuActive ? "fas fa-times" : "fas fa-bars"}></i>
          </button>
          
          <nav>
            <ul id="mainMenu">
              <li><a href="#features">Funkciók</a></li>
              <li><a href="#benefits">Miért BB Agrár?</a></li>
              <li><a href="#contact">Kapcsolat</a></li>
              <li><a href="#auth" className="btn-secondary">Bejelentkezés</a></li>
              <li><a href="#auth" className="nav-button">Regisztráció</a></li>
            </ul>
          </nav>
        </div>
        
        {/* MOBIL MENÜ */}
        <div className={`mobile-menu ${mobileMenuActive ? 'active' : ''}`}>
          <a href="#features" onClick={closeMobileMenu}>Funkciók</a>
          <a href="#benefits" onClick={closeMobileMenu}>Miért BB Agrár?</a>
          <a href="#contact" onClick={closeMobileMenu}>Kapcsolat</a>
          <a href="#auth" className="btn-secondary" onClick={closeMobileMenu}>Bejelentkezés</a>
          <a href="#auth" className="nav-button" onClick={closeMobileMenu}>Regisztráció</a>
        </div>
      </header>
      
      {/* HERO SZEKCIÓ */}
      <section className="hero">
        <div className="container hero-container">
          <div className="hero-content">
            <h1>Digitális megoldás a modern gazdálkodáshoz</h1>
            <p className="hero-subtitle">A BB Agrár egy átlátható, könnyen használható webalkalmazás, amely segít nyomon követni az állatállományt, földterületeket, pénzügyeket és napi feladatokat – egy helyen.</p>
            <div className="hero-buttons">
              <a href="#auth" className="btn-primary">Ingyenes regisztráció</a>
              <a href="#auth" className="btn-secondary">Bejelentkezés</a>
            </div>
          </div>
          <div className="hero-image">
            <div className="dashboard-mockup">
              <div style={{ background: '#1B5E20', height: '40px', display: 'flex', alignItems: 'center', padding: '0 20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <i className="fas fa-seedling" style={{ color: 'white' }}></i>
                  <span style={{ color: 'white', fontWeight: '600' }}>BB Agrár Dashboard</span>
                </div>
              </div>
              <div style={{ background: '#F9F9F9', height: '300px', padding: '20px', display: 'flex', flexDirection: 'column', gap: '15px' }}>
                <div style={{ display: 'flex', gap: '15px' }}>
                  <div style={{ flex: 1, background: 'white', borderRadius: '8px', padding: '15px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                      <div style={{ background: '#8D6E63', color: 'white', width: '40px', height: '40px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <i className="fas fa-cow"></i>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.9rem', color: '#666' }}>Állatok száma</div>
                        <div style={{ fontSize: '1.8rem', fontWeight: '700' }}>1,247</div>
                      </div>
                    </div>
                  </div>
                  <div style={{ flex: 1, background: 'white', borderRadius: '8px', padding: '15px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                      <div style={{ background: '#4CAF50', color: 'white', width: '40px', height: '40px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <i className="fas fa-tractor"></i>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.9rem', color: '#666' }}>Földterületek</div>
                        <div style={{ fontSize: '1.8rem', fontWeight: '700' }}>156 ha</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div style={{ flex: 1, background: 'white', borderRadius: '8px', padding: '15px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <div style={{ textAlign: 'center', color: '#666' }}>
                    <i className="fas fa-chart-bar" style={{ fontSize: '2rem', marginBottom: '10px', color: '#4CAF50' }}></i>
                    <div>Bevétel-kiadás statisztikák</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* BEVEZETŐ SZEKCIÓ */}
      <section className="intro">
        <div className="container">
          <h2>Mi a BB Agrár?</h2>
          <p>A BB Agrár célja, hogy a mezőgazdasági vállalkozók egyszerűen, digitálisan és pontos adatokkal tudják irányítani gazdaságukat, papírozás és káosz nélkül.</p>
        </div>
      </section>
      
      {/* FUNKCIÓK SZEKCIÓ */}
      <section className="features" id="features">
        <div className="container">
          <div className="section-title">
            <h2>Minden, amire szüksége van</h2>
            <p>A BB Agrár minden eszközt biztosít a gazdálkodás hatékony kezeléséhez</p>
          </div>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-cow"></i>
              </div>
              <h3>Állatnyilvántartás</h3>
              <p>Teljes állomány-nyilvántartás, egészségügyi információk, szaporodási ciklusok és teljesítményadatok.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-tractor"></i>
              </div>
              <h3>Földterületek kezelése</h3>
              <p>Parcellák digitalizálása, művelési napló, növényvédő szerek nyilvántartása, terméskövetés.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-tasks"></i>
              </div>
              <h3>Feladatkezelő</h3>
              <p>Napi teendők, időzített feladatok, munkafolyamatok és csapatmenedzsment eszközök.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-chart-line"></i>
              </div>
              <h3>Pénzügyi nyilvántartás</h3>
              <p>Bevételek, kiadások, költségvetés-tervezés, adózási előkészítés és nyereségesség elemzés.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-chart-pie"></i>
              </div>
              <h3>Statisztikák és kimutatások</h3>
              <p>Teljesítményjelzők, trendanalízisek, exportálható jelentések és egyéni dashboardok.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-folder"></i>
              </div>
              <h3>Dokumentumkezelés</h3>
              <p>Szerződések, számlák, engedélyek és egyéb dokumentumok biztonságos tárolása és kezelése.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* ELŐNYÖK SZEKCIÓ */}
      <section className="benefits" id="benefits">
        <div className="container benefits-container">
          <div className="benefits-content">
            <h2>Miért válassza a BB Agrár-t?</h2>
            <ul className="benefit-list">
              <li>
                <i className="fas fa-check-circle"></i>
                <div>
                  <h4>Átlátható rendszer</h4>
                  <p>Minden információ egy helyen, világos felületen, valós időben.</p>
                </div>
              </li>
              <li>
                <i className="fas fa-check-circle"></i>
                <div>
                  <h4>Gazdák igényeire szabva</h4>
                  <p>Mezőgazdasági szakemberekkel együttműködve kifejlesztett megoldások.</p>
                </div>
              </li>
              <li>
                <i className="fas fa-check-circle"></i>
                <div>
                  <h4>Időt és pénzt spórol</h4>
                  <p>Automatizált folyamatok csökkentik az adminisztrációs terheket.</p>
                </div>
              </li>
              <li>
                <i className="fas fa-check-circle"></i>
                <div>
                  <h4>Egy helyen minden adat</h4>
                  <p>Állatok, földek, pénzügyek, dokumentumok – minden összekapcsolva.</p>
                </div>
              </li>
              <li>
                <i className="fas fa-check-circle"></i>
                <div>
                  <h4>Kezdőknek is könnyen használható</h4>
                  <p>Intuitív felület, részletes útmutatók és magyar támogatás.</p>
                </div>
              </li>
            </ul>
          </div>
          <div className="benefits-image">
            <div className="illustration">
              <i className="fas fa-leaf"></i>
            </div>
          </div>
        </div>
      </section>
      
      {/* BEJELENTKEZÉS/REGISZTRÁCIÓ SZEKCIÓ */}
      <section className="auth-section" id="auth">
        <div className="container">
          <div className="section-title">
            <h2>Kezdje el használni még ma</h2>
            <p>Csatlakozzon több mint 500 mezőgazdasági vállalkozóhoz, akik már használják a BB Agrár-t</p>
          </div>
          
          <div className="auth-container">
            <div className="auth-box">
              <h3>Bejelentkezés</h3>
              <form className="auth-form" onSubmit={handleLoginSubmit}>
                <div className="form-group">
                  <label htmlFor="email">E-mail cím</label>
                  <input type="email" id="email" placeholder="pelda@gazdasag.hu" required />
                </div>
                <div className="form-group">
                  <label htmlFor="password">Jelszó</label>
                  <input type="password" id="password" placeholder="••••••••" required />
                </div>
                <button type="submit" className="btn-primary">Bejelentkezés</button>
              </form>
              <p>Elfelejtetted a jelszavad? <a href="#" className="auth-link">Jelszó visszaállítás</a></p>
            </div>
            
            <div className="auth-divider"></div>
            
            <div className="auth-box">
              <h3>Regisztráció</h3>
              <p style={{ marginBottom: '30px' }}>Hozzon létre egy ingyenes fiókot, és próbálja ki a BB Agrár-t 14 napig díjmentesen.</p>
              <a href="#" className="btn-primary" style={{ display: 'block', textAlign: 'center' }}>Regisztráció</a>
              <p>Már van fiókja? <a href="#login" className="auth-link">Jelentkezzen be</a></p>
            </div>
          </div>
        </div>
      </section>
      
      {/* LÁBLÉC */}
      <footer id="contact">
        <div className="container">
          <div className="footer-container">
            <div className="footer-about">
              <div className="footer-logo">
                <i className="fas fa-seedling"></i>
                <span>BB Agrár</span>
              </div>
              <p className="footer-description">A BB Agrár egy modern webalapú megoldás mezőgazdasági vállalkozások számára, amely egyszerűsíti és digitalizálja az adminisztrációt, nyilvántartást és gazdálkodást.</p>
            </div>
            
            <div className="footer-links">
              <h4 className="footer-heading">Gyors linkek</h4>
              <ul className="footer-links">
                <li><a href="#features">Funkciók</a></li>
                <li><a href="#benefits">Miért BB Agrár?</a></li>
                <li><a href="#auth">Bejelentkezés</a></li>
                <li><a href="#auth">Regisztráció</a></li>
              </ul>
            </div>
            
            <div className="footer-contact">
              <h4 className="footer-heading">Kapcsolat</h4>
              <ul className="footer-links">
                <li><i className="fas fa-envelope" style={{ marginRight: '10px' }}></i> info@bbagrar.hu</li>
                <li><i className="fas fa-phone" style={{ marginRight: '10px' }}></i> +36 1 234 5678</li>
                <li><i className="fas fa-map-marker-alt" style={{ marginRight: '10px' }}></i> 1234 Budapest, Agrár u. 1.</li>
              </ul>
            </div>
            
            <div className="footer-legal">
              <h4 className="footer-heading">Jogi információk</h4>
              <ul className="footer-links">
                <li><a href="#">Általános Szerződési Feltételek</a></li>
                <li><a href="#">Adatvédelmi nyilatkozat</a></li>
                <li><a href="#">Cookie szabályzat</a></li>
                <li><a href="#">GDPR tájékoztató</a></li>
              </ul>
            </div>
          </div>
          
          <div className="footer-bottom">
            <p>&copy; 2023 BB Agrár - Minden jog fenntartva.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;