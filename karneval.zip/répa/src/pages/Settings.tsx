// pages/Settings.tsx
import { useState, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useSettings } from '../context/SettingsContext';
import { useAuth } from '../auth/AuthContext';
import { 
  Moon, 
  Sun, 
  Globe, 
  Bell, 
  Shield, 
  Eye, 
  Volume2, 
  Languages,
  Save,
  RotateCcw,
  Monitor,
  Smartphone,
  Mail,
  MessageSquare,
  Award,
  Database,
  Clock,
  Palette,
  ChevronRight,
  Lock,
  Fingerprint,
  History,
  Download,
  Check
} from 'lucide-react';

// Ideiglenes beállítások típusa
interface TempSettings {
  theme: 'light' | 'dark';
  fontSize: 'small' | 'medium' | 'large';
  reducedMotion: boolean;
  highContrast: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
  desktopNotifications: boolean;
  notificationSounds: boolean;
  twoFactorAuth: boolean;
  biometricLogin: boolean;
  sessionTimeout: number;
  loginHistory: boolean;
  language: string;
  autoSave: boolean;
  compactView: boolean;
  showTips: boolean;
  telemetry: boolean;
}

const Settings = () => {
  const { isDarkMode, toggleTheme } = useTheme();
  const { settings, updateSetting, resetSettings } = useSettings();
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState<string>('megjelenes');
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  
  // Ideiglenes beállítások (amíg nem mentünk)
  const [tempSettings, setTempSettings] = useState<TempSettings>({
    theme: isDarkMode ? 'dark' : 'light',
    fontSize: settings.fontSize,
    reducedMotion: settings.reducedMotion,
    highContrast: settings.highContrast,
    emailNotifications: settings.emailNotifications,
    pushNotifications: settings.pushNotifications,
    desktopNotifications: settings.desktopNotifications,
    notificationSounds: settings.notificationSounds,
    twoFactorAuth: settings.twoFactorAuth,
    biometricLogin: settings.biometricLogin,
    sessionTimeout: settings.sessionTimeout,
    loginHistory: settings.loginHistory,
    language: settings.language,
    autoSave: settings.autoSave,
    compactView: settings.compactView,
    showTips: settings.showTips,
    telemetry: settings.telemetry,
  });

  // Alkalmazza a vizuális változásokat azonnal
  useEffect(() => {
    // Reduced motion
    if (tempSettings.reducedMotion) {
      document.documentElement.classList.add('reduce-motion');
    } else {
      document.documentElement.classList.remove('reduce-motion');
    }
    
    // High contrast
    if (tempSettings.highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
    
    // Font size
    document.documentElement.classList.remove('text-small', 'text-medium', 'text-large');
    document.documentElement.classList.add(`text-${tempSettings.fontSize}`);
    
    // Compact view
    if (tempSettings.compactView) {
      document.documentElement.classList.add('compact-view');
    } else {
      document.documentElement.classList.remove('compact-view');
    }
  }, [tempSettings.reducedMotion, tempSettings.highContrast, tempSettings.fontSize, tempSettings.compactView]);

  // Amikor betöltődnek a valódi beállítások, frissítjük a temp-et is
  useEffect(() => {
    setTempSettings({
      theme: isDarkMode ? 'dark' : 'light',
      fontSize: settings.fontSize,
      reducedMotion: settings.reducedMotion,
      highContrast: settings.highContrast,
      emailNotifications: settings.emailNotifications,
      pushNotifications: settings.pushNotifications,
      desktopNotifications: settings.desktopNotifications,
      notificationSounds: settings.notificationSounds,
      twoFactorAuth: settings.twoFactorAuth,
      biometricLogin: settings.biometricLogin,
      sessionTimeout: settings.sessionTimeout,
      loginHistory: settings.loginHistory,
      language: settings.language,
      autoSave: settings.autoSave,
      compactView: settings.compactView,
      showTips: settings.showTips,
      telemetry: settings.telemetry,
    });
  }, [settings, isDarkMode]);

  const handleTempUpdate = (key: keyof TempSettings, value: any) => {
    setTempSettings(prev => ({ ...prev, [key]: value }));
    
    // Téma esetén azonnal alkalmazzuk a változást
    if (key === 'theme') {
      if ((value === 'dark' && !isDarkMode) || (value === 'light' && isDarkMode)) {
        toggleTheme();
      }
    }
  };

  const handleSave = () => {
    // Elmentjük az összes ideiglenes beállítást
    Object.entries(tempSettings).forEach(([key, value]) => {
      if (key !== 'theme') {
        updateSetting(key as any, value);
      }
    });
    
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleReset = () => {
    if (window.confirm('Biztosan visszaállítod az alapértelmezett beállításokat?')) {
      resetSettings();
      
      // Alapértelmezett vizuális állapot visszaállítása
      document.documentElement.classList.remove('reduce-motion', 'high-contrast', 'compact-view');
      document.documentElement.classList.remove('text-small', 'text-medium', 'text-large');
      document.documentElement.classList.add('text-medium');
      
      setTempSettings({
        theme: 'light',
        fontSize: 'medium',
        reducedMotion: false,
        highContrast: false,
        emailNotifications: true,
        pushNotifications: true,
        desktopNotifications: true,
        notificationSounds: true,
        twoFactorAuth: false,
        biometricLogin: false,
        sessionTimeout: 30,
        loginHistory: true,
        language: 'hu',
        autoSave: true,
        compactView: false,
        showTips: true,
        telemetry: false,
      });
      
      if (isDarkMode) {
        toggleTheme();
      }
    }
  };

  const sections = [
    { id: 'megjelenes', icon: Palette, label: 'Megjelenés' },
    { id: 'ertesitesek', icon: Bell, label: 'Értesítések' },
    { id: 'adatvedelem', icon: Shield, label: 'Adatvédelem' },
    { id: 'nyelv', icon: Languages, label: 'Nyelv és régió' },
    { id: 'egyeb', icon: Database, label: 'Egyéb beállítások' }
  ];

  return (
    <div className={`max-w-6xl mx-auto settings-preview text-${tempSettings.fontSize}`}>
      {/* Fejléc */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Beállítások</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {user ? `${user.username} fiókjának beállításai` : 'Testreszabhatod az alkalmazás működését'}
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={handleReset}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors flex items-center gap-2"
          >
            <RotateCcw size={18} />
            Alaphelyzet
          </button>
          <button
            onClick={handleSave}
            className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors flex items-center gap-2 relative"
          >
            {saveSuccess ? (
              <>
                <Check size={18} />
                Elmentve
              </>
            ) : (
              <>
                <Save size={18} />
                Mentés
              </>
            )}
          </button>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Bal oldali navigáció */}
        <div className="w-64 flex-shrink-0">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden sticky top-4">
            {sections.map((section) => {
              const Icon = section.icon;
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 transition-colors ${
                    activeSection === section.id
                      ? 'bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 border-l-4 border-green-600'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Icon size={20} />
                  <span className="flex-1 text-left">{section.label}</span>
                  <ChevronRight size={16} className="text-gray-400" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Jobb oldali tartalom */}
        <div className="flex-1 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          {/* Megjelenés szekció */}
          {activeSection === 'megjelenes' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Megjelenés</h2>
              
              {/* Téma választó */}
              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Palette className="text-green-600" size={20} />
                  <h3 className="font-medium text-gray-800 dark:text-white">Téma</h3>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => handleTempUpdate('theme', 'light')}
                    className={`flex flex-col items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                      tempSettings.theme === 'light' 
                        ? 'border-green-500 bg-green-50 dark:bg-green-900/30' 
                        : 'border-gray-200 dark:border-gray-700 hover:border-green-300'
                    }`}
                  >
                    <Sun size={24} className={tempSettings.theme === 'light' ? 'text-green-600' : 'text-gray-600 dark:text-gray-400'} />
                    <span className="text-sm text-gray-700 dark:text-gray-300">Világos</span>
                    {tempSettings.theme === 'light' && (
                      <span className="text-xs text-green-600 dark:text-green-400">✓</span>
                    )}
                  </button>
                  
                  <button
                    onClick={() => handleTempUpdate('theme', 'dark')}
                    className={`flex flex-col items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                      tempSettings.theme === 'dark' 
                        ? 'border-green-500 bg-green-50 dark:bg-green-900/30' 
                        : 'border-gray-200 dark:border-gray-700 hover:border-green-300'
                    }`}
                  >
                    <Moon size={24} className={tempSettings.theme === 'dark' ? 'text-green-600' : 'text-gray-600 dark:text-gray-400'} />
                    <span className="text-sm text-gray-700 dark:text-gray-300">Sötét</span>
                    {tempSettings.theme === 'dark' && (
                      <span className="text-xs text-green-600 dark:text-green-400">✓</span>
                    )}
                  </button>
                  
                  <button 
                    onClick={() => {
                      const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                      handleTempUpdate('theme', systemPrefersDark ? 'dark' : 'light');
                    }}
                    className={`flex flex-col items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                      tempSettings.theme === (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
                        ? 'border-green-500 bg-green-50 dark:bg-green-900/30' 
                        : 'border-gray-200 dark:border-gray-700 hover:border-green-300'
                    }`}
                  >
                    <Monitor size={24} className={tempSettings.theme === (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') ? 'text-green-600' : 'text-gray-600 dark:text-gray-400'} />
                    <span className="text-sm text-gray-700 dark:text-gray-300">Rendszer</span>
                  </button>
                </div>
              </div>

              {/* Betűméret */}
              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Eye className="text-green-600" size={20} />
                  <h3 className="font-medium text-gray-800 dark:text-white">Betűméret</h3>
                </div>
                <div className="flex gap-3">
                  {(['small', 'medium', 'large'] as const).map((size) => (
                    <button
                      key={size}
                      onClick={() => handleTempUpdate('fontSize', size)}
                      className={`flex-1 py-2 px-3 rounded-lg border-2 transition-all ${
                        tempSettings.fontSize === size
                          ? 'border-green-500 bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                          : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-green-300'
                      }`}
                    >
                      {size === 'small' && 'Kicsi'}
                      {size === 'medium' && 'Közepes'}
                      {size === 'large' && 'Nagy'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Egyéb megjelenés beállítások */}
              <div className="space-y-3">
                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Eye size={18} className="text-gray-600 dark:text-gray-400" />
                    <span className="text-gray-700 dark:text-gray-300">Csökkentett mozgás</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.reducedMotion}
                    onChange={(e) => handleTempUpdate('reducedMotion', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Eye size={18} className="text-gray-600 dark:text-gray-400" />
                    <span className="text-gray-700 dark:text-gray-300">Magas kontraszt</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.highContrast}
                    onChange={(e) => handleTempUpdate('highContrast', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>
              </div>
            </div>
          )}

          {/* Értesítések szekció */}
          {activeSection === 'ertesitesek' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Értesítések</h2>
              
              <div className="space-y-3">
                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Mail size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Email értesítések</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Fontos frissítések emailben</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.emailNotifications}
                    onChange={(e) => handleTempUpdate('emailNotifications', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Smartphone size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Push értesítések</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Azonnali értesítések a böngészőben</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.pushNotifications}
                    onChange={(e) => handleTempUpdate('pushNotifications', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Monitor size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Asztali értesítések</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Értesítések az asztali alkalmazásban</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.desktopNotifications}
                    onChange={(e) => handleTempUpdate('desktopNotifications', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Volume2 size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Hangjelzések</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Hang lejátszása értesítéskor</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.notificationSounds}
                    onChange={(e) => handleTempUpdate('notificationSounds', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>
              </div>
            </div>
          )}

          {/* Adatvédelem szekció */}
          {activeSection === 'adatvedelem' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Adatvédelem és biztonság</h2>
              
              <div className="space-y-3">
                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Lock size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Kétfaktoros hitelesítés</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Növeld a fiókod biztonságát</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.twoFactorAuth}
                    onChange={(e) => handleTempUpdate('twoFactorAuth', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Fingerprint size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Biometrikus bejelentkezés</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Ujjlenyomat vagy arcazonosítás</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.biometricLogin}
                    onChange={(e) => handleTempUpdate('biometricLogin', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <div className="flex items-center gap-3 mb-2">
                    <Clock size={18} className="text-gray-600 dark:text-gray-400" />
                    <span className="text-gray-700 dark:text-gray-300">Munkamenet időtúllépés</span>
                  </div>
                  <select
                    value={tempSettings.sessionTimeout}
                    onChange={(e) => handleTempUpdate('sessionTimeout', Number(e.target.value))}
                    className="w-full p-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  >
                    <option value={15}>15 perc</option>
                    <option value={30}>30 perc</option>
                    <option value={60}>1 óra</option>
                    <option value={120}>2 óra</option>
                    <option value={240}>4 óra</option>
                  </select>
                </div>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <History size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Bejelentkezési előzmények</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Rögzítjük a bejelentkezéseidet</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.loginHistory}
                    onChange={(e) => handleTempUpdate('loginHistory', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>
              </div>
            </div>
          )}

          {/* Nyelv és régió szekció */}
          {activeSection === 'nyelv' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Nyelv és régió</h2>
              
              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Globe className="text-green-600" size={20} />
                  <h3 className="font-medium text-gray-800 dark:text-white">Nyelv</h3>
                </div>
                <select
                  value={tempSettings.language}
                  onChange={(e) => handleTempUpdate('language', e.target.value)}
                  className="w-full p-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                >
                  <option value="hu">Magyar</option>
                  <option value="en">English</option>
                  <option value="de">Deutsch</option>
                  <option value="ro">Română</option>
                </select>
              </div>

              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Award className="text-green-600" size={20} />
                  <h3 className="font-medium text-gray-800 dark:text-white">Régió</h3>
                </div>
                <select
                  value="hu"
                  onChange={() => {}}
                  className="w-full p-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                >
                  <option value="hu">Magyarország</option>
                  <option value="ro">Románia</option>
                  <option value="sk">Szlovákia</option>
                  <option value="rs">Szerbia</option>
                  <option value="hr">Horvátország</option>
                  <option value="si">Szlovénia</option>
                  <option value="at">Ausztria</option>
                  <option value="de">Németország</option>
                </select>
              </div>
            </div>
          )}

          {/* Egyéb beállítások */}
          {activeSection === 'egyeb' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Egyéb beállítások</h2>
              
              <div className="space-y-3">
                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Save size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Automatikus mentés</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Változások automatikus mentése</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.autoSave}
                    onChange={(e) => handleTempUpdate('autoSave', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Eye size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Kompakt nézet</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Sűrített megjelenítés</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.compactView}
                    onChange={(e) => handleTempUpdate('compactView', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <MessageSquare size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Tippek megjelenítése</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Hasznos tippek az alkalmazásban</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.showTips}
                    onChange={(e) => handleTempUpdate('showTips', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Database size={18} className="text-gray-600 dark:text-gray-400" />
                    <div>
                      <span className="text-gray-700 dark:text-gray-300">Adatok küldése</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Névtelen használati statisztikák</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSettings.telemetry}
                    onChange={(e) => handleTempUpdate('telemetry', e.target.checked)}
                    className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                </label>

                <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <h3 className="font-medium text-gray-800 dark:text-white mb-3">Adatok kezelése</h3>
                  <div className="space-y-2">
                    <button className="w-full text-left px-3 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg flex items-center gap-2">
                      <Download size={16} />
                      Összes adat exportálása
                    </button>
                    <button className="w-full text-left px-3 py-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg flex items-center gap-2">
                      <Database size={16} />
                      Fiók törlése
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;