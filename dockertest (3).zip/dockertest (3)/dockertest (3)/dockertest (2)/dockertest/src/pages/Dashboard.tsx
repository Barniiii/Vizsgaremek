import { useEffect, useState } from 'react';
import { Beef, DollarSign, Calendar, TrendingUp, LucideIcon } from 'lucide-react';
import { getAnimalCount, getBalance } from '../db/operations';
import { useTheme } from '../context/ThemeContext';

interface Stats {
  animalCount: number;
  balance: number;
}

interface StatCard {
  icon: LucideIcon;
  label: string;
  value: number | string;
  lightColor: string;
  darkColor: string;
}

interface ThemeClasses {
  pageTitle: string;
  cardBg: string;
  cardLabel: string;
  cardValue: string;
  sectionTitle: string;
  button: string;
  placeholderText: string;
  shadow: string;
}

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<Stats>({
    animalCount: 0,
    balance: 0,
  });
  
  const { theme } = useTheme(); // Itt theme a neve, nem isDarkMode
  const isDarkMode = theme === 'dark'; // Konvertáljuk boolean-ná ha kell

  // Adatok betöltése
  const loadStats = async (): Promise<void> => {
    try {
      const animalCount = await getAnimalCount();
      const balance = await getBalance();
      setStats({
        animalCount: Number(animalCount),
        balance: Number(balance),
      });
    } catch (error) {
      console.error('Hiba az adatok betöltése közben:', error);
    }
  };

  // Adatok betöltése komponens mountoláskor
  useEffect(() => {
    loadStats();
  }, []);

  // Eseményfigyelő az adatok frissítéséhez, amikor az oldal újra fókuszba kerül
  useEffect(() => {
    const handleFocus = (): void => {
      loadStats();
    };

    window.addEventListener('focus', handleFocus);
    
    // Cleanup
    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, []);

  const statCards: StatCard[] = [
    {
      icon: Beef,
      label: 'Állatlétszám',
      value: stats.animalCount,
      lightColor: 'bg-green-100 text-green-700',
      darkColor: 'bg-green-900 text-green-100',
    },
    {
      icon: DollarSign,
      label: 'Pénzügyi egyenleg',
      value: `${stats.balance.toLocaleString('hu-HU')} Ft`,
      lightColor: 'bg-green-100 text-green-700',
      darkColor: 'bg-green-900 text-green-100',
    },
    {
      icon: Calendar,
      label: 'Közelgő feladatok',
      value: 0,
      lightColor: 'bg-green-100 text-green-700',
      darkColor: 'bg-green-900 text-green-100',
    },
    {
      icon: TrendingUp,
      label: 'Havi növekedés',
      value: '0%',
      lightColor: 'bg-green-100 text-green-700',
      darkColor: 'bg-green-900 text-green-100',
    },
  ];

  // Témától függő osztályok
  const getThemeClasses = (): ThemeClasses => {
    return {
      pageTitle: isDarkMode ? 'text-gray-100' : 'text-gray-800',
      cardBg: isDarkMode ? 'bg-gray-800' : 'bg-white',
      cardLabel: isDarkMode ? 'text-gray-300' : 'text-gray-600',
      cardValue: isDarkMode ? 'text-gray-100' : 'text-gray-800',
      sectionTitle: isDarkMode ? 'text-gray-100' : 'text-gray-800',
      button: isDarkMode 
        ? 'bg-green-700 hover:bg-green-600' 
        : 'bg-green-600 hover:bg-green-700',
      placeholderText: isDarkMode ? 'text-gray-400' : 'text-gray-600',
      shadow: isDarkMode ? 'shadow-gray-900' : 'shadow',
    };
  };

  const themeClasses = getThemeClasses();

  return (
    <div>
      <h1 className={`text-3xl font-bold ${themeClasses.pageTitle} mb-8`}>Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div 
              key={index} 
              className={`${themeClasses.cardBg} rounded-lg ${themeClasses.shadow} p-6 transition-colors duration-200`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${
                  isDarkMode ? card.darkColor : card.lightColor
                }`}>
                  <Icon size={24} />
                </div>
              </div>
              <p className={`${themeClasses.cardLabel} text-sm mb-1`}>{card.label}</p>
              <p className={`text-2xl font-bold ${themeClasses.cardValue}`}>{card.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className={`${themeClasses.cardBg} rounded-lg ${themeClasses.shadow} p-6 transition-colors duration-200`}>
          <h2 className={`text-xl font-bold ${themeClasses.sectionTitle} mb-4`}>Legutóbbi tevékenységek</h2>
          <div className="space-y-3">
            <p className={themeClasses.placeholderText}>Nincsenek legutóbbi tevékenységek</p>
          </div>
        </div>

        <div className={`${themeClasses.cardBg} rounded-lg ${themeClasses.shadow} p-6 transition-colors duration-200`}>
          <h2 className={`text-xl font-bold ${themeClasses.sectionTitle} mb-4`}>Gyors műveletek</h2>
          <div className="space-y-3">
            <button className={`w-full ${themeClasses.button} text-white px-4 py-2 rounded-lg transition-colors duration-200`}>
              Új állat hozzáadása
            </button>
            <button className={`w-full ${themeClasses.button} text-white px-4 py-2 rounded-lg transition-colors duration-200`}>
              Új kiadás rögzítése
            </button>
            <button className={`w-full ${themeClasses.button} text-white px-4 py-2 rounded-lg transition-colors duration-200`}>
              Új bevétel rögzítése
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;