import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Animals from './pages/Animals';
import Lands from './pages/Lands';
import Budget from './pages/Budget';
import Clients from './pages/Clients';
import Documents from './pages/Documents';
import Marketplace from './pages/Marketplace';
import Profile from './pages/Profile';
import Settings from './pages/Settings'; // <-- Új import
import Landing from "./pages/Landing";
import { AuthProvider } from './auth/AuthContext';
import { ThemeProvider } from './context/ThemeContext'; // <-- Új import
import ProtectedRoute from './auth/ProtectedRoute';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

const ProtectedLayout = () => (
  <ProtectedRoute>
    <Layout>
      <Outlet />
    </Layout>
  </ProtectedRoute>
);

function App() {
  return (
    <AuthProvider>
      <ThemeProvider> {/* <-- ThemeProvider hozzáadva */}
        <Router>
          <Routes>
            {/* PUBLIC */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* PROTECTED */}
            <Route element={<ProtectedLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/animals" element={<Animals />} />
              <Route path="/lands" element={<Lands />} />
              <Route path="/budget" element={<Budget />} />
              <Route path="/clients" element={<Clients />} />
              <Route path="/documents" element={<Documents />} />
              <Route path="/marketplace" element={<Marketplace />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/settings" element={<Settings />} /> {/* <-- ÚJ ROUTE */}
            </Route>
          </Routes>
        </Router>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;