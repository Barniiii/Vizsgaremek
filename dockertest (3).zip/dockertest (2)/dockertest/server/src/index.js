import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';

import { query } from './db.js';
import { signToken, requireAuth } from './auth.js';

const app = express();

const {
  PORT = '4000',
  CORS_ORIGIN = 'http://localhost:5173',
} = process.env;

app.use(cors({ origin: CORS_ORIGIN, credentials: false }));
app.use(express.json({ limit: '1mb' }));

app.get('/health', async (req, res) => {
  try {
    await query('SELECT 1');
    return res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ ok: false });
  }
});

// --- Auth ---
app.post('/api/auth/register', async (req, res) => {
  const { username, email, password } = req.body || {};
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'username, email, password required' });
  }
  if (String(password).length < 6) {
    return res.status(400).json({ error: 'password must be at least 6 characters' });
  }

  const existing = await query('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1', [username, email]);
  if (existing.length) {
    return res.status(409).json({ error: 'User already exists' });
  }

  const password_hash = await bcrypt.hash(String(password), 10);
  const result = await query('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)', [username, email, password_hash]);
  const user = { id: result.insertId, username, email };
  const token = signToken({ userId: user.id, username: user.username });
  return res.status(201).json({ token, user });
});

app.post('/api/auth/login', async (req, res) => {
  const { identifier, password } = req.body || {};
  if (!identifier || !password) {
    return res.status(400).json({ error: 'identifier, password required' });
  }

  const users = await query('SELECT id, username, email, password_hash FROM users WHERE username = ? OR email = ? LIMIT 1', [identifier, identifier]);
  const u = users[0];
  if (!u) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await bcrypt.compare(String(password), String(u.password_hash));
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  const token = signToken({ userId: u.id, username: u.username });
  return res.json({ token, user: { id: u.id, username: u.username, email: u.email } });
});

app.get('/api/me', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const rows = await query('SELECT id, username, email, created_at FROM users WHERE id = ? LIMIT 1', [userId]);
  if (!rows[0]) return res.status(404).json({ error: 'User not found' });
  return res.json({ user: rows[0] });
});

// --- Dashboard ---
app.get('/api/dashboard/stats', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const animalCountRows = await query('SELECT COUNT(*) AS count FROM animals WHERE user_id = ?', [userId]);
  const incomeRows = await query('SELECT COALESCE(SUM(amount), 0) AS total FROM incomes WHERE user_id = ?', [userId]);
  const expenseRows = await query('SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE user_id = ?', [userId]);

  const animalCount = Number(animalCountRows[0]?.count || 0);
  const balance = Number(incomeRows[0]?.total || 0) - Number(expenseRows[0]?.total || 0);

  return res.json({ animalCount, balance });
});

// --- Animals ---
app.get('/api/animals', requireAuth, async (req, res) => {
  try {
    const userId = req.user.userId;
    
    // MÓDOSÍTOTT: name, breed, birth_date mezők hozzáadva
    const rows = await query(
      'SELECT id, name, species, breed, identifier, birth_date, stable, notes, created_at FROM animals WHERE user_id = ? ORDER BY created_at DESC',
      [userId]
    );
    
    return res.json({ items: rows });
  } catch (error) {
    console.error('Error fetching animals:', error);
    return res.status(500).json({ error: 'Failed to fetch animals' });
  }
});

app.post('/api/animals', requireAuth, async (req, res) => {
  try {
    const { name, species, breed, identifier, birth_date, stable, notes } = req.body;
    const userId = req.user.userId;
    
    // Validáció
    if (!species || !identifier) {
      return res.status(400).json({ error: 'Species and identifier are required' });
    }
    
    // MÓDOSÍTOTT: age helyett birth_date
    const result = await query(
      'INSERT INTO animals (user_id, name, species, breed, identifier, birth_date, stable, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [userId, name || null, species, breed || null, identifier, birth_date || null, stable || null, notes || null]
    );
    
    return res.json({ success: true, id: result.insertId });
  } catch (error) {
    console.error('Error adding animal:', error);
    return res.status(500).json({ error: 'Failed to add animal' });
  }
});

// Állat törlése - EZ HIÁNYZIK A KÓDBÓL, ADJUK HOZZÁ
app.delete('/api/animals/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.userId;
    
    const result = await query(
      'DELETE FROM animals WHERE id = ? AND user_id = ?',
      [id, userId]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Animal not found' });
    }
    
    return res.json({ success: true });
  } catch (error) {
    console.error('Error deleting animal:', error);
    return res.status(500).json({ error: 'Failed to delete animal' });
  }
});

// --- Lands ---
app.delete('/api/lands/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.userId;

    const result = await query(
      'DELETE FROM lands WHERE id = ? AND user_id = ?',
      [id, userId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Land not found' });
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('Error deleting land:', error);
    return res.status(500).json({ error: 'Failed to delete land' });
  }
});

app.get('/api/lands', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const rows = await query('SELECT * FROM lands WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  return res.json({ items: rows });
});

app.post('/api/lands', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const { name, plot_number = null, area } = req.body || {};
  if (!name || area === undefined) return res.status(400).json({ error: 'name and area required' });
  const result = await query('INSERT INTO lands (user_id, name, plot_number, area) VALUES (?, ?, ?, ?)', [userId, name, plot_number, area]);
  const rows = await query('SELECT * FROM lands WHERE id = ?', [result.insertId]);
  return res.status(201).json({ item: rows[0] });
});

// --- Budget: expenses/incomes ---
app.get('/api/expenses', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const rows = await query('SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC', [userId]);
  return res.json({ items: rows });
});

app.post('/api/expenses', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const { amount, category, description = null, date } = req.body || {};
  if (amount === undefined || !category || !date) return res.status(400).json({ error: 'amount, category, date required' });
  const result = await query('INSERT INTO expenses (user_id, amount, category, description, date) VALUES (?, ?, ?, ?, ?)', [userId, amount, category, description, date]);
  const rows = await query('SELECT * FROM expenses WHERE id = ?', [result.insertId]);
  return res.status(201).json({ item: rows[0] });
});

app.get('/api/incomes', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const rows = await query('SELECT * FROM incomes WHERE user_id = ? ORDER BY date DESC', [userId]);
  return res.json({ items: rows });
});

app.post('/api/incomes', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const { amount, category, description = null, date } = req.body || {};
  if (amount === undefined || !category || !date) return res.status(400).json({ error: 'amount, category, date required' });
  const result = await query('INSERT INTO incomes (user_id, amount, category, description, date) VALUES (?, ?, ?, ?, ?)', [userId, amount, category, description, date]);
  const rows = await query('SELECT * FROM incomes WHERE id = ?', [result.insertId]);
  return res.status(201).json({ item: rows[0] });
});

// --- Clients ---
app.get('/api/clients', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const rows = await query('SELECT * FROM clients WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  return res.json({ items: rows });
});

app.post('/api/clients', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const { name, email = null, phone = null, type = null, notes = null } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name required' });
  const result = await query('INSERT INTO clients (user_id, name, email, phone, type, notes) VALUES (?, ?, ?, ?, ?, ?)', [userId, name, email, phone, type, notes]);
  const rows = await query('SELECT * FROM clients WHERE id = ?', [result.insertId]);
  return res.status(201).json({ item: rows[0] });
});

// --- Marketplace ---
app.get('/api/marketplace', async (req, res) => {
  const rows = await query('SELECT * FROM marketplace WHERE status = "active" ORDER BY created_at DESC');
  return res.json({ items: rows });
});

app.post('/api/marketplace', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const { title, description = null, type, price, image_url = null } = req.body || {};
  if (!title || !type || price === undefined) return res.status(400).json({ error: 'title, type, price required' });
  const result = await query('INSERT INTO marketplace (user_id, title, description, type, price, image_url) VALUES (?, ?, ?, ?, ?, ?)', [userId, title, description, type, price, image_url]);
  const rows = await query('SELECT * FROM marketplace WHERE id = ?', [result.insertId]);
  return res.status(201).json({ item: rows[0] });
});

// --- Documents (metadata only) ---
app.get('/api/documents', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const rows = await query('SELECT * FROM documents WHERE user_id = ? ORDER BY upload_date DESC', [userId]);
  return res.json({ items: rows });
});

app.post('/api/documents', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const { title, category, filename, filepath } = req.body || {};
  if (!title || !category || !filename || !filepath) return res.status(400).json({ error: 'title, category, filename, filepath required' });
  const result = await query('INSERT INTO documents (user_id, title, category, filename, filepath) VALUES (?, ?, ?, ?, ?)', [userId, title, category, filename, filepath]);
  const rows = await query('SELECT * FROM documents WHERE id = ?', [result.insertId]);
  return res.status(201).json({ item: rows[0] });
});

app.listen(Number(PORT), () => {
  console.log(`API listening on :${PORT}`);
});