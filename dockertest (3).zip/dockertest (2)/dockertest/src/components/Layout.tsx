import { ReactNode, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Beef, 
  Map, 
  FileText, 
  DollarSign, 
  Users, 
  ShoppingCart,
  ChevronDown,
  LogOut,
  Settings,
  User,
  HelpCircle
} from 'lucide-react';
import { useAuth } from '../auth/AuthContext';

interface LayoutProps {
  children: ReactNode;
}

interface UserType {
  username?: string;
  email?: string;
}

const Layout = ({ children }: LayoutProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth() as { user: UserType | null; logout: () => void };
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState<boolean>(false);

  const navItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/animals', icon: Beef, label: 'Állatok' },
    { path: '/lands', icon: Map, label: 'Földek' },
    { path: '/budget', icon: DollarSign, label: 'Költségvetés' },
    { path: '/clients', icon: Users, label: 'Ügyfelek' },
    { path: '/documents', icon: FileText, label: 'Dokumentáció' },
    { path: '/marketplace', icon: ShoppingCart, label: 'Piactér' },
  ];

  // Felhasználó nevéből betűjel
  const getInitials = (): string => {
    if (!user?.username) return '?';
    return user.username
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Bal oldali menü - zöld háttér */}
      <aside className="w-64 bg-green-700 text-white flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-green-600">
          <h1 className="text-2xl font-bold">AgárAdmin</h1>
          <p className="text-sm text-green-100 mt-1">Mezőgazdasági rendszer</p>
        </div>

        {/* Navigáció */}
        <nav className="flex-1 p-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${
                  isActive
                    ? 'bg-green-800 text-white'
                    : 'text-green-50 hover:bg-green-600'
                }`}
              >
                <Icon size={20} />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Profil menü a bal alsó sarokban */}
        <div className="p-4 border-t border-green-600 relative">
          {/* Profil gomb */}
          <button
            onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
            className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-green-600 transition-colors group"
          >
            {/* Profilkép */}
            <div className="w-10 h-10 rounded-md bg-green-800 flex items-center justify-center text-white font-bold text-lg shadow-lg group-hover:ring-2 group-hover:ring-green-300 transition-all">
              <span>{getInitials()}</span>
            </div>
            
            <div className="flex-1 text-left">
              <p className="text-sm font-medium text-white">{user?.username || 'Felhasználó'}</p>
              <p className="text-xs text-green-200">{user?.email || 'nincs email'}</p>
            </div>
            
            <ChevronDown 
              size={16} 
              className={`text-green-200 transition-transform duration-200 ${
                isProfileMenuOpen ? 'rotate-180' : ''
              }`} 
            />
          </button>

          {/* Legördülő menü */}
          {isProfileMenuOpen && (
            <>
              {/* Külső kattintás detektálása */}
              <div 
                className="fixed inset-0 z-40" 
                onClick={() => setIsProfileMenuOpen(false)}
              />
              
              {/* Menü - a gomb fölé nyílik */}
              <div className="absolute bottom-full left-0 w-full mb-2 bg-green-800 rounded-lg border border-green-600 shadow-2xl overflow-hidden z-50">
                {/* Fejléc */}
                <div className="px-4 py-3 border-b border-green-700">
                  <p className="text-sm text-green-300">Bejelentkezve mint</p>
                  <p className="text-white font-medium">{user?.username || 'Felhasználó'}</p>
                  {user?.email && (
                    <p className="text-xs text-green-300 mt-0.5">{user.email}</p>
                  )}
                </div>

                {/* Menüpontok */}
                <div className="py-2">
                  <button
                    onClick={() => {
                      navigate('/profile');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full px-4 py-2.5 text-left text-green-100 hover:bg-green-700 flex items-center gap-3 transition-colors"
                  >
                    <User size={16} />
                    <span className="text-sm">Profil</span>
                  </button>
                  
                  <button className="w-full px-4 py-2.5 text-left text-green-100 hover:bg-green-700 flex items-center gap-3 transition-colors">
                    <Settings size={16} />
                    <span className="text-sm">Beállítások</span>
                  </button>
                  
                  <button className="w-full px-4 py-2.5 text-left text-green-100 hover:bg-green-700 flex items-center gap-3 transition-colors">
                    <HelpCircle size={16} />
                    <span className="text-sm">Segítség</span>
                  </button>
                  
                  <div className="border-t border-green-700 my-2"></div>
                  
                  <button
                    onClick={() => {
                      logout();
                      navigate('/login', { replace: true });
                    }}
                    className="w-full px-4 py-2.5 text-left text-red-300 hover:bg-green-700 hover:text-red-200 flex items-center gap-3 transition-colors"
                  >
                    <LogOut size={16} />
                    <span className="text-sm">Kilépés</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </aside>

      {/* Fő tartalom */}
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;