import { useState } from 'react';
import { useAuth } from '../auth/AuthContext';
import { User, Mail, Phone, MapPin, Save, Camera, Key, Bell, Shield } from 'lucide-react';

interface ProfileData {
  username: string;
  email: string;
  phone: string;
  location: string;
  bio: string;
  avatar: string | null;
}

const Profile = () => {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'notifications'>('profile');
  
  // Példa profil adatok - ezeket később adatbázisból kell betölteni
  const [profileData, setProfileData] = useState<ProfileData>({
    username: user?.username || 'Kiss Péter',
    email: user?.email || 'peter.kiss@example.com',
    phone: '+36 30 123 4567',
    location: 'Budapest, Magyarország',
    bio: 'Mezőgazdasági szakember',
    avatar: null,
  });

  const handleSave = (): void => {
    // Itt mentés adatbázisba
    console.log('Mentett adatok:', profileData);
    setIsEditing(false);
  };

  // Betűjel a névből
  const getInitials = (): string => {
    return profileData.username
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Fejléc */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Profil beállítások</h1>
        {!isEditing ? (
          <button
            onClick={() => setIsEditing(true)}
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-colors"
          >
            Szerkesztés
          </button>
        ) : (
          <div className="flex gap-3">
            <button
              onClick={() => setIsEditing(false)}
              className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
            >
              Mégse
            </button>
            <button
              onClick={handleSave}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-colors flex items-center gap-2"
            >
              <Save size={18} />
              Mentés
            </button>
          </div>
        )}
      </div>

      {/* Tabok */}
      <div className="flex gap-1 mb-6 border-b">
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-4 py-2 font-medium text-sm transition-colors relative ${
            activeTab === 'profile'
              ? 'text-green-600 border-b-2 border-green-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Profil adatok
        </button>
        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2 font-medium text-sm transition-colors relative ${
            activeTab === 'security'
              ? 'text-green-600 border-b-2 border-green-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Biztonság
        </button>
        <button
          onClick={() => setActiveTab('notifications')}
          className={`px-4 py-2 font-medium text-sm transition-colors relative ${
            activeTab === 'notifications'
              ? 'text-green-600 border-b-2 border-green-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Értesítések
        </button>
      </div>

      {/* Profil adatok tab */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Bal oldal - Profilkép */}
            <div className="md:w-1/3">
              <div className="bg-gray-50 rounded-lg p-6 text-center">
                <div className="relative inline-block">
                  {/* Profilkép */}
                  <div className="w-32 h-32 rounded-full bg-gradient-to-br from-green-600 to-green-700 flex items-center justify-center text-white font-bold text-4xl shadow-lg mx-auto">
                    {profileData.avatar ? (
                      <img src={profileData.avatar} alt="Profile" className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <span>{getInitials()}</span>
                    )}
                  </div>
                  
                  {isEditing && (
                    <button className="absolute bottom-0 right-0 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-colors">
                      <Camera size={18} className="text-gray-600" />
                    </button>
                  )}
                </div>
                
                <h2 className="text-xl font-bold text-gray-800 mt-4">{profileData.username}</h2>
                <p className="text-gray-500">{profileData.bio}</p>
              </div>
            </div>

            {/* Jobb oldal - Adatok */}
            <div className="md:w-2/3 space-y-4">
              <div className="grid grid-cols-1 gap-4">
                {/* Név */}
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <User className="text-green-600 mt-1" size={20} />
                  <div className="flex-1">
                    <label className="text-sm text-gray-500">Teljes név</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={profileData.username}
                        onChange={(e) => setProfileData({...profileData, username: e.target.value})}
                        className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <p className="font-medium text-gray-800">{profileData.username}</p>
                    )}
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <Mail className="text-green-600 mt-1" size={20} />
                  <div className="flex-1">
                    <label className="text-sm text-gray-500">Email cím</label>
                    {isEditing ? (
                      <input
                        type="email"
                        value={profileData.email}
                        onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                        className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <p className="font-medium text-gray-800">{profileData.email}</p>
                    )}
                  </div>
                </div>

                {/* Telefon */}
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <Phone className="text-green-600 mt-1" size={20} />
                  <div className="flex-1">
                    <label className="text-sm text-gray-500">Telefonszám</label>
                    {isEditing ? (
                      <input
                        type="tel"
                        value={profileData.phone}
                        onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                        className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <p className="font-medium text-gray-800">{profileData.phone}</p>
                    )}
                  </div>
                </div>

                {/* Helyszín */}
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <MapPin className="text-green-600 mt-1" size={20} />
                  <div className="flex-1">
                    <label className="text-sm text-gray-500">Helyszín</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={profileData.location}
                        onChange={(e) => setProfileData({...profileData, location: e.target.value})}
                        className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <p className="font-medium text-gray-800">{profileData.location}</p>
                    )}
                  </div>
                </div>

                {/* Bemutatkozás */}
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <User className="text-green-600 mt-1" size={20} />
                  <div className="flex-1">
                    <label className="text-sm text-gray-500">Bemutatkozás</label>
                    {isEditing ? (
                      <textarea
                        value={profileData.bio}
                        onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
                        rows={3}
                        className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <p className="font-medium text-gray-800">{profileData.bio}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Biztonság tab */}
      {activeTab === 'security' && (
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="space-y-6">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Key className="text-green-600" size={24} />
              <div className="flex-1">
                <h3 className="font-medium text-gray-800">Jelszó módosítása</h3>
                <p className="text-sm text-gray-500">Utoljára módosítva: 2024.01.15</p>
              </div>
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm">
                Módosítás
              </button>
            </div>

            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Shield className="text-green-600" size={24} />
              <div className="flex-1">
                <h3 className="font-medium text-gray-800">Kétfaktoros hitelesítés</h3>
                <p className="text-sm text-gray-500">Növeld a fiókod biztonságát</p>
              </div>
              <button className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm">
                Beállítás
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Értesítések tab */}
      {activeTab === 'notifications' && (
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Bell className="text-green-600" size={20} />
                <div>
                  <h3 className="font-medium text-gray-800">Email értesítések</h3>
                  <p className="text-sm text-gray-500">Kapj értesítést új üzenetekről</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Bell className="text-green-600" size={20} />
                <div>
                  <h3 className="font-medium text-gray-800">Rendszer értesítések</h3>
                  <p className="text-sm text-gray-500">Frissítések és karbantartások</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;