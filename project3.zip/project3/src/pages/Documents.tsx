import { useEffect, useState } from 'react';
import { Plus, X, FileText, Download } from 'lucide-react';
import { getDocuments, addDocument } from '../db/operations';

interface Document {
  id: number;
  title: string;
  category: string;
  filename: string;
  filepath: string;
  upload_date: string;
}

const Documents = () => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    filename: '',
  });

  const loadDocuments = async () => {
    const userId = 1;
    const data = await getDocuments(userId);
    setDocuments(data as Document[]);
  };

  useEffect(() => {
    loadDocuments();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const userId = 1;
    await addDocument(userId, {
      title: formData.title,
      category: formData.category,
      filename: formData.filename,
      filepath: `/uploads/${formData.filename}`,
    });
    setFormData({ title: '', category: '', filename: '' });
    setShowForm(false);
    await loadDocuments();
  };

  const categories = ['Bérleti szerződések', 'Támogatási kérelmek', 'Hivatalos iratok', 'Egyéb'];

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Dokumentáció</h1>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus size={20} />
          Új dokumentum
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">Új dokumentum feltöltése</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Cím *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Kategória *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="">Válassz kategóriát...</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Fájlnév *</label>
                <input
                  type="text"
                  value={formData.filename}
                  onChange={(e) => setFormData({ ...formData, filename: e.target.value })}
                  required
                  placeholder="pl. szerződés_2024.pdf"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  Mentés
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {categories.map((category) => {
          const count = documents.filter((doc) => doc.category === category).length;
          return (
            <div key={category} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-green-100 text-green-700 rounded-lg">
                  <FileText size={24} />
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-1">{category}</p>
              <p className="text-2xl font-bold text-gray-800">{count} db</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-green-50 border-b border-green-100">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Cím</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Kategória</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Fájlnév</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Feltöltés dátuma</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Műveletek</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {documents.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                  Még nincsenek dokumentumok feltöltve
                </td>
              </tr>
            ) : (
              documents.map((doc) => (
                <tr key={doc.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-800">{doc.title}</td>
                  <td className="px-6 py-4 text-sm text-gray-800">{doc.category}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{doc.filename}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(doc.upload_date).toLocaleDateString('hu-HU')}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <button className="text-green-600 hover:text-green-700 flex items-center gap-1">
                      <Download size={16} />
                      Letöltés
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Documents;
