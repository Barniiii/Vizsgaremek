import { useEffect, useState } from 'react';
import { Plus, X } from 'lucide-react';
import { getLands, addLand } from '../db/operations';

interface Land {
  id: number;
  name: string;
  plot_number?: string;
  area: number;
}

const Lands = () => {
  const [lands, setLands] = useState<Land[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    plot_number: '',
    area: '',
  });

  const loadLands = async () => {
    const userId = 1;
    const data = await getLands(userId);
    setLands(data as Land[]);
  };

  useEffect(() => {
    loadLands();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const userId = 1;
    await addLand(userId, {
      name: formData.name,
      plot_number: formData.plot_number,
      area: parseFloat(formData.area),
    });
    setFormData({ name: '', plot_number: '', area: '' });
    setShowForm(false);
    await loadLands();
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Földek</h1>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus size={20} />
          Új föld
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">Új földterület hozzáadása</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Név *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Helyrajzi szám</label>
                <input
                  type="text"
                  value={formData.plot_number}
                  onChange={(e) => setFormData({ ...formData, plot_number: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Területnagyság (ha) *</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.area}
                  onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  Mentés
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-green-50 border-b border-green-100">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Név</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Helyrajzi szám</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Területnagyság (ha)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {lands.length === 0 ? (
              <tr>
                <td colSpan={3} className="px-6 py-8 text-center text-gray-500">
                  Még nincsenek földterületek rögzítve
                </td>
              </tr>
            ) : (
              lands.map((land) => (
                <tr key={land.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-800">{land.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-800">{land.plot_number || '-'}</td>
                  <td className="px-6 py-4 text-sm text-gray-800">{land.area} ha</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Lands;
