import { useEffect, useState } from 'react';
import { Plus, X } from 'lucide-react';
import { getAnimals, addAnimal } from '../db/operations';

interface Animal {
  id: number;
  species: string;
  identifier: string;
  age?: number;
  stable?: string;
  notes?: string;
}

const Animals = () => {
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    species: '',
    identifier: '',
    age: '',
    stable: '',
    notes: '',
  });

  const loadAnimals = async () => {
    const userId = 1;
    const data = await getAnimals(userId);
    setAnimals(data as Animal[]);
  };

  useEffect(() => {
    loadAnimals();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const userId = 1;
    await addAnimal(userId, {
      species: formData.species,
      identifier: formData.identifier,
      age: formData.age ? parseInt(formData.age) : undefined,
      stable: formData.stable,
      notes: formData.notes,
    });
    setFormData({ species: '', identifier: '', age: '', stable: '', notes: '' });
    setShowForm(false);
    await loadAnimals();
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Állatok</h1>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus size={20} />
          Új állat
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">Új állat hozzáadása</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Faj *</label>
                <input
                  type="text"
                  value={formData.species}
                  onChange={(e) => setFormData({ ...formData, species: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Azonosító *</label>
                <input
                  type="text"
                  value={formData.identifier}
                  onChange={(e) => setFormData({ ...formData, identifier: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Életkor</label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Istálló</label>
                <input
                  type="text"
                  value={formData.stable}
                  onChange={(e) => setFormData({ ...formData, stable: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Megjegyzések</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  Mentés
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-green-50 border-b border-green-100">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Faj</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Azonosító</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Életkor</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Istálló</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Megjegyzések</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {animals.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                  Még nincsenek állatok rögzítve
                </td>
              </tr>
            ) : (
              animals.map((animal) => (
                <tr key={animal.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-800">{animal.species}</td>
                  <td className="px-6 py-4 text-sm text-gray-800">{animal.identifier}</td>
                  <td className="px-6 py-4 text-sm text-gray-800">{animal.age || '-'}</td>
                  <td className="px-6 py-4 text-sm text-gray-800">{animal.stable || '-'}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{animal.notes || '-'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Animals;
