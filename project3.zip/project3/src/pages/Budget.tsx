import { useEffect, useState } from 'react';
import { Plus, X, TrendingUp, TrendingDown } from 'lucide-react';
import { getExpenses, getIncomes, addExpense, addIncome, getBalance } from '../db/operations';

interface Transaction {
  id: number;
  amount: number;
  category: string;
  description?: string;
  date: string;
}

const Budget = () => {
  const [expenses, setExpenses] = useState<Transaction[]>([]);
  const [incomes, setIncomes] = useState<Transaction[]>([]);
  const [balance, setBalance] = useState(0);
  const [activeTab, setActiveTab] = useState<'expenses' | 'incomes'>('expenses');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    category: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });

  const loadData = async () => {
    const userId = 1;
    const [expensesData, incomesData, balanceData] = await Promise.all([
      getExpenses(userId),
      getIncomes(userId),
      getBalance(userId)
    ]);
    setExpenses(expensesData as Transaction[]);
    setIncomes(incomesData as Transaction[]);
    setBalance(Number(balanceData));
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const userId = 1;
    const data = {
      amount: parseFloat(formData.amount),
      category: formData.category,
      description: formData.description,
      date: formData.date,
    };

    if (activeTab === 'expenses') {
      await addExpense(userId, data);
    } else {
      await addIncome(userId, data);
    }

    setFormData({ amount: '', category: '', description: '', date: new Date().toISOString().split('T')[0] });
    setShowForm(false);
    await loadData();
  };

  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const totalIncomes = incomes.reduce((sum, inc) => sum + inc.amount, 0);

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Költségvetés</h1>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus size={20} />
          Új tétel
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-100 text-green-700 rounded-lg">
              <TrendingUp size={24} />
            </div>
            <p className="text-gray-600 text-sm">Bevételek</p>
          </div>
          <p className="text-2xl font-bold text-gray-800">{totalIncomes.toLocaleString('hu-HU')} Ft</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-red-100 text-red-700 rounded-lg">
              <TrendingDown size={24} />
            </div>
            <p className="text-gray-600 text-sm">Kiadások</p>
          </div>
          <p className="text-2xl font-bold text-gray-800">{totalExpenses.toLocaleString('hu-HU')} Ft</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className={`p-2 rounded-lg ${balance >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              <TrendingUp size={24} />
            </div>
            <p className="text-gray-600 text-sm">Egyenleg</p>
          </div>
          <p className={`text-2xl font-bold ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {balance.toLocaleString('hu-HU')} Ft
          </p>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">
                Új {activeTab === 'expenses' ? 'kiadás' : 'bevétel'}
              </h2>
              <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Típus</label>
                <select
                  value={activeTab}
                  onChange={(e) => setActiveTab(e.target.value as 'expenses' | 'incomes')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="expenses">Kiadás</option>
                  <option value="incomes">Bevétel</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Összeg (Ft) *</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Kategória *</label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Leírás</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Dátum *</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  Mentés
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab('expenses')}
              className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
                activeTab === 'expenses'
                  ? 'text-green-700 border-b-2 border-green-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Kiadások
            </button>
            <button
              onClick={() => setActiveTab('incomes')}
              className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
                activeTab === 'incomes'
                  ? 'text-green-700 border-b-2 border-green-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Bevételek
            </button>
          </div>
        </div>

        <div className="overflow-hidden">
          <table className="w-full">
            <thead className="bg-green-50 border-b border-green-100">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Dátum</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Kategória</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Leírás</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-700">Összeg</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {(activeTab === 'expenses' ? expenses : incomes).length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                    Még nincsenek {activeTab === 'expenses' ? 'kiadások' : 'bevételek'} rögzítve
                  </td>
                </tr>
              ) : (
                (activeTab === 'expenses' ? expenses : incomes).map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-800">{item.date}</td>
                    <td className="px-6 py-4 text-sm text-gray-800">{item.category}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{item.description || '-'}</td>
                    <td className="px-6 py-4 text-sm text-right font-medium text-gray-800">
                      {item.amount.toLocaleString('hu-HU')} Ft
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Budget;
