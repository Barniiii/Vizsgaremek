import { getDb, saveDb } from './database';

export const getAnimalCount = async (userId: number) => {
  const db = await getDb();
  const result = db.exec('SELECT COUNT(*) as count FROM animals WHERE user_id = ?', [userId]);
  return result[0]?.values[0]?.[0] || 0;
};

export const getBalance = async (userId: number) => {
  const db = await getDb();
  const incomeResult = db.exec('SELECT SUM(amount) as total FROM incomes WHERE user_id = ?', [userId]);
  const expenseResult = db.exec('SELECT SUM(amount) as total FROM expenses WHERE user_id = ?', [userId]);

  const income = incomeResult[0]?.values[0]?.[0] || 0;
  const expense = expenseResult[0]?.values[0]?.[0] || 0;

  return Number(income) - Number(expense);
};

export const getAnimals = async (userId: number) => {
  const db = await getDb();
  const result = db.exec('SELECT * FROM animals WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  if (!result[0]) return [];

  return result[0].values.map(row => ({
    id: row[0],
    user_id: row[1],
    species: row[2],
    identifier: row[3],
    age: row[4],
    stable: row[5],
    notes: row[6],
    created_at: row[7],
  }));
};

export const addAnimal = async (userId: number, animal: { species: string; identifier: string; age?: number; stable?: string; notes?: string }) => {
  const db = await getDb();
  db.run('INSERT INTO animals (user_id, species, identifier, age, stable, notes) VALUES (?, ?, ?, ?, ?, ?)',
    [userId, animal.species, animal.identifier, animal.age, animal.stable, animal.notes]);
  saveDb();
};

export const getLands = async (userId: number) => {
  const db = await getDb();
  const result = db.exec('SELECT * FROM lands WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  if (!result[0]) return [];

  return result[0].values.map(row => ({
    id: row[0],
    user_id: row[1],
    name: row[2],
    plot_number: row[3],
    area: row[4],
    created_at: row[5],
  }));
};

export const addLand = async (userId: number, land: { name: string; plot_number?: string; area: number }) => {
  const db = await getDb();
  db.run('INSERT INTO lands (user_id, name, plot_number, area) VALUES (?, ?, ?, ?)',
    [userId, land.name, land.plot_number, land.area]);
  saveDb();
};

export const getExpenses = async (userId: number) => {
  const db = await getDb();
  const result = db.exec('SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC', [userId]);
  if (!result[0]) return [];

  return result[0].values.map(row => ({
    id: row[0],
    user_id: row[1],
    amount: row[2],
    category: row[3],
    description: row[4],
    date: row[5],
    created_at: row[6],
  }));
};

export const addExpense = async (userId: number, expense: { amount: number; category: string; description?: string; date: string }) => {
  const db = await getDb();
  db.run('INSERT INTO expenses (user_id, amount, category, description, date) VALUES (?, ?, ?, ?, ?)',
    [userId, expense.amount, expense.category, expense.description, expense.date]);
  saveDb();
};

export const getIncomes = async (userId: number) => {
  const db = await getDb();
  const result = db.exec('SELECT * FROM incomes WHERE user_id = ? ORDER BY date DESC', [userId]);
  if (!result[0]) return [];

  return result[0].values.map(row => ({
    id: row[0],
    user_id: row[1],
    amount: row[2],
    category: row[3],
    description: row[4],
    date: row[5],
    created_at: row[6],
  }));
};

export const addIncome = async (userId: number, income: { amount: number; category: string; description?: string; date: string }) => {
  const db = await getDb();
  db.run('INSERT INTO incomes (user_id, amount, category, description, date) VALUES (?, ?, ?, ?, ?)',
    [userId, income.amount, income.category, income.description, income.date]);
  saveDb();
};

export const getClients = async (userId: number) => {
  const db = await getDb();
  const result = db.exec('SELECT * FROM clients WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  if (!result[0]) return [];

  return result[0].values.map(row => ({
    id: row[0],
    user_id: row[1],
    name: row[2],
    email: row[3],
    phone: row[4],
    type: row[5],
    notes: row[6],
    created_at: row[7],
  }));
};

export const addClient = async (userId: number, client: { name: string; email?: string; phone?: string; type?: string; notes?: string }) => {
  const db = await getDb();
  db.run('INSERT INTO clients (user_id, name, email, phone, type, notes) VALUES (?, ?, ?, ?, ?, ?)',
    [userId, client.name, client.email, client.phone, client.type, client.notes]);
  saveDb();
};

export const getMarketplace = async () => {
  const db = await getDb();
  const result = db.exec('SELECT * FROM marketplace WHERE status = "active" ORDER BY created_at DESC');
  if (!result[0]) return [];

  return result[0].values.map(row => ({
    id: row[0],
    user_id: row[1],
    title: row[2],
    description: row[3],
    type: row[4],
    price: row[5],
    image_url: row[6],
    status: row[7],
    created_at: row[8],
  }));
};

export const addMarketplaceItem = async (userId: number, item: { title: string; description?: string; type: string; price: number; image_url?: string }) => {
  const db = await getDb();
  db.run('INSERT INTO marketplace (user_id, title, description, type, price, image_url) VALUES (?, ?, ?, ?, ?, ?)',
    [userId, item.title, item.description, item.type, item.price, item.image_url]);
  saveDb();
};

export const getDocuments = async (userId: number) => {
  const db = await getDb();
  const result = db.exec('SELECT * FROM documents WHERE user_id = ? ORDER BY upload_date DESC', [userId]);
  if (!result[0]) return [];

  return result[0].values.map(row => ({
    id: row[0],
    user_id: row[1],
    title: row[2],
    category: row[3],
    filename: row[4],
    filepath: row[5],
    upload_date: row[6],
  }));
};

export const addDocument = async (userId: number, doc: { title: string; category: string; filename: string; filepath: string }) => {
  const db = await getDb();
  db.run('INSERT INTO documents (user_id, title, category, filename, filepath) VALUES (?, ?, ?, ?, ?)',
    [userId, doc.title, doc.category, doc.filename, doc.filepath]);
  saveDb();
};
