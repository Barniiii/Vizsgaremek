import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Animals from './pages/Animals';
import Lands from './pages/Lands';
import Budget from './pages/Budget';
import Clients from './pages/Clients';
import Documents from './pages/Documents';
import Marketplace from './pages/Marketplace';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/animals" element={<Animals />} />
          <Route path="/lands" element={<Lands />} />
          <Route path="/budget" element={<Budget />} />
          <Route path="/clients" element={<Clients />} />
          <Route path="/documents" element={<Documents />} />
          <Route path="/marketplace" element={<Marketplace />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
