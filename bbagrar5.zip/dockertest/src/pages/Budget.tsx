import { useEffect, useState } from 'react';
import { Plus, X, TrendingUp, TrendingDown, Edit2, Trash2, PieChart, BarChart3 } from 'lucide-react';
import { 
  getExpenses, 
  getIncomes, 
  addExpense, 
  addIncome, 
  getBalance, 
  deleteExpense, 
  deleteIncome 
} from '../db/operations';

interface Transaction {
  id: number;
  user_id?: number;
  amount: number;
  category: string;
  description?: string | null;
  date: string;
  created_at?: string;
}

// Segédfüggvény a számok formázásához
const formatCurrency = (value: number): string => {
  // Ellenőrizzük, hogy szám-e
  if (typeof value !== 'number' || isNaN(value)) {
    return '0 Ft';
  }
  
  // Formázás magyar módra: 1 234 567 Ft
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' Ft';
};

const Budget = () => {
  const [expenses, setExpenses] = useState<Transaction[]>([]);
  const [incomes, setIncomes] = useState<Transaction[]>([]);
  const [balance, setBalance] = useState(0);
  const [activeTab, setActiveTab] = useState<'expenses' | 'incomes'>('expenses');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showChart, setShowChart] = useState(false);
  const [loading, setLoading] = useState(true);
  const [useExistingCategory, setUseExistingCategory] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    category: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [expensesData, incomesData, balanceData] = await Promise.all([
        getExpenses(),
        getIncomes(),
        getBalance()
      ]);
      
      setExpenses(expensesData as Transaction[]);
      setIncomes(incomesData as Transaction[]);
      setBalance(Number(balanceData));
    } catch (error) {
      console.error('Hiba az adatok betöltésekor:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const data = {
        amount: parseFloat(formData.amount),
        category: formData.category,
        description: formData.description || undefined,
        date: formData.date,
      };

      if (editingId) {
        // Szerkesztés - itt majd kell update függvény
        alert('Szerkesztés még nem elérhető!');
        return;
      } else {
        // Új hozzáadás
        if (activeTab === 'expenses') {
          await addExpense(data);
        } else {
          await addIncome(data);
        }
      }

      resetForm();
      await loadData();
    } catch (error) {
      console.error('Hiba a mentés során:', error);
      alert('Hiba történt a mentés során!');
    }
  };

  const handleDelete = async (id: number, type: 'expense' | 'income') => {
    if (!confirm('Biztosan törölni szeretnéd ezt a tételt?')) return;

    try {
      if (type === 'expense') {
        await deleteExpense(id);
      } else {
        await deleteIncome(id);
      }
      await loadData();
    } catch (error) {
      console.error('Hiba a törlés során:', error);
      alert('Hiba történt a törlés során!');
    }
  };

  const handleEdit = (item: Transaction) => {
    setFormData({
      amount: item.amount.toString(),
      category: item.category,
      description: item.description || '',
      date: item.date,
    });
    setEditingId(item.id);
    setShowForm(true);
    // Szerkesztésnél mindig meglévő kategóriát használunk
    setUseExistingCategory(true);
  };

  const resetForm = () => {
    setFormData({ 
      amount: '', 
      category: '', 
      description: '', 
      date: new Date().toISOString().split('T')[0] 
    });
    setEditingId(null);
    setShowForm(false);
    setUseExistingCategory(false);
  };

  // Összegek számítása - biztosítjuk, hogy számok legyenek
  const totalExpenses = expenses.reduce((sum, exp) => sum + (Number(exp.amount) || 0), 0);
  const totalIncomes = incomes.reduce((sum, inc) => sum + (Number(inc.amount) || 0), 0);

  // Egyedi kategóriák a dropdown-hoz
  const expenseCategories = [...new Set(expenses.map(e => e.category))];
  const incomeCategories = [...new Set(incomes.map(i => i.category))];
  const currentCategories = activeTab === 'expenses' ? expenseCategories : incomeCategories;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Adatok betöltése...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Költségvetés</h1>
        <div className="flex gap-3">
          <button
            onClick={() => setShowChart(!showChart)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            {showChart ? <BarChart3 size={20} /> : <PieChart size={20} />}
            {showChart ? 'Lista nézet' : 'Diagram nézet'}
          </button>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            <Plus size={20} />
            Új tétel
          </button>
        </div>
      </div>

      {/* Statisztika kártyák */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-100 text-green-700 rounded-lg">
              <TrendingUp size={24} />
            </div>
            <p className="text-gray-600 text-sm">Bevételek</p>
          </div>
          <p className="text-2xl font-bold text-gray-800">{formatCurrency(totalIncomes)}</p>
          <p className="text-sm text-gray-500 mt-1">{incomes.length} tétel</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-red-100 text-red-700 rounded-lg">
              <TrendingDown size={24} />
            </div>
            <p className="text-gray-600 text-sm">Kiadások</p>
          </div>
          <p className="text-2xl font-bold text-gray-800">{formatCurrency(totalExpenses)}</p>
          <p className="text-sm text-gray-500 mt-1">{expenses.length} tétel</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className={`p-2 rounded-lg ${balance >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              <TrendingUp size={24} />
            </div>
            <p className="text-gray-600 text-sm">Egyenleg</p>
          </div>
          <p className={`text-2xl font-bold ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(balance)}
          </p>
        </div>
      </div>

      {/* Tétel hozzáadás/szerkesztés modal - JAVÍTVA: kategória választás */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">
                {editingId ? 'Szerkesztés' : 'Új tétel'}
              </h2>
              <button onClick={resetForm} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Típus</label>
                <select
                  value={activeTab}
                  onChange={(e) => {
                    setActiveTab(e.target.value as 'expenses' | 'incomes');
                    setUseExistingCategory(false); // Váltáskor alaphelyzet
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="expenses">Kiadás</option>
                  <option value="incomes">Bevétel</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Összeg (Ft) *</label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="pl.: 10000"
                />
              </div>

              {/* Kategória választás - JAVÍTVA */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-sm font-medium text-gray-700">Kategória *</label>
                  {currentCategories.length > 0 && !editingId && (
                    <button
                      type="button"
                      onClick={() => setUseExistingCategory(!useExistingCategory)}
                      className="text-xs text-green-600 hover:text-green-800"
                    >
                      {useExistingCategory ? 'Új kategória megadása' : 'Meglévő kategória választása'}
                    </button>
                  )}
                </div>
                
                {useExistingCategory && currentCategories.length > 0 ? (
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="">Válassz kategóriát</option>
                    {currentCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                    placeholder={activeTab === 'expenses' 
                      ? "pl.: Takarmány, Állatorvos, Gyógyszer..." 
                      : "pl.: Értékesítés, Támogatás, Bérleti díj..."}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                )}
                
                {currentCategories.length > 0 && !useExistingCategory && !editingId && (
                  <p className="text-xs text-gray-500 mt-1">
                    ✏️ Új kategóriát adsz meg. Kattints a "Meglévő kategória választása" linkre, ha listából szeretnél választani.
                  </p>
                )}
                
                {currentCategories.length === 0 && (
                  <p className="text-xs text-gray-500 mt-1">
                    Még nincs ilyen típusú kategória, add meg az elsőt!
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Leírás</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Részletek a tételről..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Dátum *</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              
              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  {editingId ? 'Módosítás' : 'Mentés'}
                </button>
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Táblázat nézet */}
      {!showChart && (
        <div className="bg-white rounded-lg shadow">
          <div className="border-b border-gray-200">
            <div className="flex">
              <button
                onClick={() => setActiveTab('expenses')}
                className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
                  activeTab === 'expenses'
                    ? 'text-green-700 border-b-2 border-green-700'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Kiadások ({expenses.length})
              </button>
              <button
                onClick={() => setActiveTab('incomes')}
                className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
                  activeTab === 'incomes'
                    ? 'text-green-700 border-b-2 border-green-700'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Bevételek ({incomes.length})
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-green-50 border-b border-green-100">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Dátum</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Kategória</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Leírás</th>
                  <th className="px-6 py-3 text-right text-sm font-semibold text-gray-700">Összeg</th>
                  <th className="px-6 py-3 text-right text-sm font-semibold text-gray-700">Műveletek</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {(activeTab === 'expenses' ? expenses : incomes).length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                      Még nincsenek {activeTab === 'expenses' ? 'kiadások' : 'bevételek'} rögzítve
                    </td>
                  </tr>
                ) : (
                  (activeTab === 'expenses' ? expenses : incomes)
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm text-gray-800">
                          {new Date(item.date).toLocaleDateString('hu-HU')}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-800">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            {item.category}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">{item.description || '-'}</td>
                        <td className="px-6 py-4 text-sm text-right font-medium text-gray-800">
                          {formatCurrency(Number(item.amount))}
                        </td>
                        <td className="px-6 py-4 text-sm text-right">
                          <button
                            onClick={() => handleEdit(item)}
                            className="text-blue-600 hover:text-blue-800 mr-3"
                            title="Szerkesztés"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => handleDelete(item.id, activeTab === 'expenses' ? 'expense' : 'income')}
                            className="text-red-600 hover:text-red-800"
                            title="Törlés"
                          >
                            <Trash2 size={18} />
                          </button>
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Diagram nézet */}
      {showChart && activeTab === 'expenses' && expenses.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Kiadások megoszlása</h2>
          <div className="space-y-3">
            {Object.entries(
              expenses.reduce((acc, exp) => {
                acc[exp.category] = (acc[exp.category] || 0) + Number(exp.amount);
                return acc;
              }, {} as Record<string, number>)
            )
              .sort((a, b) => b[1] - a[1])
              .map(([category, amount]) => {
                const percentage = (amount / totalExpenses) * 100;
                return (
                  <div key={category}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium text-gray-700">{category}</span>
                      <span className="text-gray-600">{formatCurrency(amount)} ({percentage.toFixed(1)}%)</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-green-600 h-2 rounded-full"
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Ha nincs adat a diagramhoz */}
      {showChart && activeTab === 'expenses' && expenses.length === 0 && (
        <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
          Nincs megjeleníthető adat
        </div>
      )}
    </div>
  );
};

export default Budget;