import React, { useEffect, useState } from 'react';
import { Plus, X, FileText, Download, Trash2, Link as LinkIcon } from 'lucide-react';
import { getDocuments, addDocument, deleteDocument } from '../db/operations';
import { apiRequest } from '../api/http';

interface Document {
  id: number;
  title: string;
  category: string;
  filename: string;
  filepath: string;
  upload_date: string;
  entity_type: 'animal' | 'land' | 'client' | 'general';
  entity_id: number | null;
  entity_name?: string;
  file_size?: number;
  mime_type?: string;
}

interface Entity {
  id: number;
  name: string;
  identifier?: string;
  plot_number?: string;
  company_name?: string;
}

const Documents: React.FC = () => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [animals, setAnimals] = useState<Entity[]>([]);
  const [lands, setLands] = useState<Entity[]>([]);
  const [clients, setClients] = useState<Entity[]>([]);
  
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    entity_type: 'general' as 'animal' | 'land' | 'client' | 'general',
    entity_id: '',
    file: null as File | null
  });

  const loadDocuments = async () => {
    const data = await getDocuments();
    setDocuments(data as Document[]);
  };

  const loadEntities = async () => {
    try {
      const token = localStorage.getItem('bbagrar_token');
      const [animalsData, landsData, clientsData] = await Promise.all([
        apiRequest<Entity[]>('/api/documents/entities/animals', { token }),
        apiRequest<Entity[]>('/api/documents/entities/lands', { token }),
        apiRequest<Entity[]>('/api/documents/entities/clients', { token })
      ]);
      
      setAnimals(animalsData);
      setLands(landsData);
      setClients(clientsData);
    } catch (error) {
      console.error('Error loading entities:', error);
    }
  };

  useEffect(() => {
    loadDocuments();
    loadEntities();
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFormData({ ...formData, file, title: file.name });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.file) {
      alert('Kérlek válassz ki egy fájlt!');
      return;
    }

    setLoading(true);
    setUploadProgress(0);

    const formDataToSend = new FormData();
    formDataToSend.append('file', formData.file);
    formDataToSend.append('title', formData.title);
    formDataToSend.append('category', formData.category);
    formDataToSend.append('entity_type', formData.entity_type);
    
    if (formData.entity_id) {
      formDataToSend.append('entity_id', formData.entity_id);
    }

    try {
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      await addDocument(formDataToSend);

      clearInterval(progressInterval);
      setUploadProgress(100);
      
      setTimeout(() => {
        setFormData({ 
          title: '', 
          category: '', 
          entity_type: 'general',
          entity_id: '',
          file: null 
        });
        setShowForm(false);
        setUploadProgress(0);
        loadDocuments();
      }, 500);
    } catch (error) {
      console.error('Error uploading document:', error);
      alert('Hiba történt a feltöltés során!');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number, filename: string) => {
    if (window.confirm(`Biztosan törölni szeretnéd a(z) "${filename}" dokumentumot?`)) {
      try {
        await deleteDocument(id);
        await loadDocuments();
      } catch (error) {
        console.error('Error deleting document:', error);
        alert('Hiba történt a törlés során!');
      }
    }
  };

  const handleDownload = async (id: number, filename: string) => {
    try {
      const token = localStorage.getItem('bbagrar_token');
      const response = await fetch(`/api/documents/${id}/download`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) throw new Error('Download failed');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading document:', error);
      alert('Hiba történt a letöltés során!');
    }
  };

  const categories = ['Bérleti szerződések', 'Támogatási kérelmek', 'Hivatalos iratok', 'Számlák', 'Egyéb'];

  const getEntityDisplay = (doc: Document) => {
    if (!doc.entity_id) return '-';
    
    switch (doc.entity_type) {
      case 'animal':
        return `Állat: ${doc.entity_name || 'Ismeretlen'}`;
      case 'land':
        return `Föld: ${doc.entity_name || 'Ismeretlen'}`;
      case 'client':
        return `Kliens: ${doc.entity_name || 'Ismeretlen'}`;
      default:
        return '-';
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Dokumentáció</h1>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus size={20} />
          Új dokumentum
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">Új dokumentum feltöltése</h2>
              <button 
                onClick={() => setShowForm(false)} 
                className="text-gray-500 hover:text-gray-700"
                disabled={loading}
              >
                <X size={24} />
              </button>
            </div>
            
            {uploadProgress > 0 && uploadProgress < 100 && (
              <div className="mb-4">
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-green-600 h-2.5 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
                <p className="text-sm text-gray-600 mt-1 text-center">
                  Feltöltés: {uploadProgress}%
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Fájl kiválasztása *
                </label>
                <input
                  type="file"
                  onChange={handleFileChange}
                  required
                  disabled={loading}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Támogatott formátumok: PDF, DOC, DOCX, XLS, XLSX, JPG, PNG (max 10MB)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Cím *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  disabled={loading}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Kategória *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  required
                  disabled={loading}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="">Válassz kategóriát...</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Kapcsolódó entitás
                </label>
                <select
                  value={formData.entity_type}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    entity_type: e.target.value as 'animal' | 'land' | 'client' | 'general',
                    entity_id: '' 
                  })}
                  disabled={loading}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="general">Általános</option>
                  <option value="animal">Állat</option>
                  <option value="land">Föld</option>
                  <option value="client">Kliens</option>
                </select>
              </div>

              {formData.entity_type !== 'general' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Válassz {formData.entity_type === 'animal' ? 'állatot' : 
                             formData.entity_type === 'land' ? 'földet' : 'klienset'} *
                  </label>
                  <select
                    value={formData.entity_id}
                    onChange={(e) => setFormData({ ...formData, entity_id: e.target.value })}
                    required
                    disabled={loading}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="">Válassz...</option>
                    {formData.entity_type === 'animal' && animals.map(animal => (
                      <option key={animal.id} value={animal.id}>
                        {animal.name} ({animal.identifier})
                      </option>
                    ))}
                    {formData.entity_type === 'land' && lands.map(land => (
                      <option key={land.id} value={land.id}>
                        {land.name} {land.plot_number ? `- ${land.plot_number}` : ''}
                      </option>
                    ))}
                    {formData.entity_type === 'client' && clients.map(client => (
                      <option key={client.id} value={client.id}>
                        {client.name} {client.company_name ? `(${client.company_name})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {loading ? 'Feltöltés...' : 'Feltöltés'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  disabled={loading}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors disabled:bg-gray-200 disabled:cursor-not-allowed"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {categories.map((category) => {
          const count = documents.filter((doc) => doc.category === category).length;
          return (
            <div key={category} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-green-100 text-green-700 rounded-lg">
                  <FileText size={24} />
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-1">{category}</p>
              <p className="text-2xl font-bold text-gray-800">{count} db</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-green-50 border-b border-green-100">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Cím</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Kategória</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Kapcsolódó</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Fájlnév</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Méret</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Feltöltés dátuma</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Műveletek</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {documents.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center text-gray-500">
                  Még nincsenek dokumentumok feltöltve
                </td>
              </tr>
            ) : (
              documents.map((doc) => (
                <tr key={doc.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-800 font-medium">
                    {doc.title}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-800">
                    {doc.category}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center gap-1 text-gray-600">
                      <LinkIcon size={14} />
                      <span>{getEntityDisplay(doc)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {doc.filename}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {formatFileSize(doc.file_size)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(doc.upload_date).toLocaleDateString('hu-HU')}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleDownload(doc.id, doc.filename)}
                        className="text-green-600 hover:text-green-700 flex items-center gap-1"
                        title="Letöltés"
                      >
                        <Download size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(doc.id, doc.filename)}
                        className="text-red-600 hover:text-red-700 flex items-center gap-1"
                        title="Törlés"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Documents;