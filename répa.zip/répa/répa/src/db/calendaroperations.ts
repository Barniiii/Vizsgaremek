import { apiRequest } from '../api/http';

export interface CalendarEvent {
  id?: number;
  title: string;
  description?: string;
  event_date: string; // YYYY-MM-DD
  event_time?: string; // HH:MM
  end_date?: string; // YYYY-MM-DD
  end_time?: string; // HH:MM
  event_type: 'task' | 'appointment' | 'feeding' | 'vet' | 'harvest' | 'other';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'completed' | 'cancelled';
  location?: string;
  animal_id?: number;
  recurring_type: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'none';
  recurring_interval?: number;
  recurring_end_date?: string;
  reminder_before?: number;
  color?: string;
  created_at?: string;
  updated_at?: string;
}

export interface CalendarEventWithAnimal extends CalendarEvent {
  animal_name?: string;
  animal_species?: string;
}

// Token lekérése a localStorage-ból
function getToken(): string | null {
  return localStorage.getItem('bbagrar_token');
}

// Események lekérése dátum intervallum alapján
export const getEvents = async (
  startDate: string,
  endDate: string
): Promise<CalendarEventWithAnimal[]> => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: CalendarEventWithAnimal[] }>(
      `/api/calendar/events?startDate=${startDate}&endDate=${endDate}`, 
      { token }
    );
    return data.items || [];
  } catch (error) {
    console.error('Error fetching events:', error);
    return [];
  }
};

// Egy nap eseményeinek lekérése
export const getEventsByDate = async (date: string): Promise<CalendarEventWithAnimal[]> => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: CalendarEventWithAnimal[] }>(
      `/api/calendar/events?date=${date}`, 
      { token }
    );
    return data.items || [];
  } catch (error) {
    console.error('Error fetching events by date:', error);
    return [];
  }
};

// Egy esemény lekérése ID alapján
export const getEventById = async (id: number): Promise<CalendarEventWithAnimal | undefined> => {
  const token = getToken();
  try {
    const data = await apiRequest<CalendarEventWithAnimal>(
      `/api/calendar/events/${id}`, 
      { token }
    );
    return data;
  } catch (error) {
    console.error('Error fetching event:', error);
    return undefined;
  }
};

// Új esemény hozzáadása
export const addEvent = async (event: Omit<CalendarEvent, 'id' | 'created_at' | 'updated_at'>): Promise<number> => {
  const token = getToken();
  try {
    const response = await apiRequest<{ id: number }>('/api/calendar/events', {
      method: 'POST',
      token,
      body: event
    });
    return response.id;
  } catch (error) {
    console.error('Error adding event:', error);
    throw error;
  }
};

// Esemény módosítása
export const updateEvent = async (id: number, event: Partial<CalendarEvent>): Promise<void> => {
  const token = getToken();
  try {
    await apiRequest(`/api/calendar/events/${id}`, {
      method: 'PUT',
      token,
      body: event
    });
  } catch (error) {
    console.error('Error updating event:', error);
    throw error;
  }
};

// Esemény törlése
export const deleteEvent = async (id: number): Promise<void> => {
  const token = getToken();
  try {
    await apiRequest(`/api/calendar/events/${id}`, {
      method: 'DELETE',
      token
    });
  } catch (error) {
    console.error('Error deleting event:', error);
    throw error;
  }
};

// Esemény státuszának módosítása
export const updateEventStatus = async (id: number, status: CalendarEvent['status']): Promise<void> => {
  const token = getToken();
  try {
    await apiRequest(`/api/calendar/events/${id}/status`, {
      method: 'PATCH',
      token,
      body: { status }
    });
  } catch (error) {
    console.error('Error updating event status:', error);
    throw error;
  }
};

// Közelgő események lekérése
export const getUpcomingEvents = async (days: number = 7): Promise<CalendarEventWithAnimal[]> => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: CalendarEventWithAnimal[] }>(
      `/api/calendar/events/upcoming?days=${days}`, 
      { token }
    );
    return data.items || [];
  } catch (error) {
    console.error('Error fetching upcoming events:', error);
    return [];
  }
};

// Események típus szerinti statisztika
export const getEventStats = async (year: number, month: number): Promise<any> => {
  const token = getToken();
  try {
    const data = await apiRequest(
      `/api/calendar/events/stats?year=${year}&month=${month}`, 
      { token }
    );
    return data;
  } catch (error) {
    console.error('Error fetching event stats:', error);
    return [];
  }
};