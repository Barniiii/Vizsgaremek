import { useEffect, useState } from "react";

export default function Users() {

  const [users, setUsers] = useState<any[]>([]);
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    role: "viewer"
  });

  const token = localStorage.getItem("token");

  async function loadUsers() {

    try {

      const res = await fetch("http://localhost:4000/api/admin/users", {
        headers: {
          Authorization: "Bearer " + token
        }
      });

      if (!res.ok) {
        console.log("Backend hiba:", res.status);
        setUsers([]);
        return;
      }

      const data = await res.json();

      if (Array.isArray(data)) {
        setUsers(data);
      } else {
        setUsers([]);
      }

    } catch (err) {
      console.log("Fetch hiba:", err);
      setUsers([]);
    }
  }

  useEffect(() => {
    loadUsers();
  }, []);

  async function createUser(e: any) {

    e.preventDefault();

    try {

      const res = await fetch("http://localhost:4000/api/admin/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token
        },
        body: JSON.stringify(form)
      });

      if (!res.ok) {
        console.log("User létrehozás hiba:", res.status);
        return;
      }

      setForm({
        username: "",
        email: "",
        password: "",
        role: "viewer"
      });

      loadUsers();

    } catch (err) {
      console.log("Create user fetch hiba:", err);
    }
  }

  return (
    <div>

      <h1>Felhasználók</h1>

      <form onSubmit={createUser}>

        <input
          placeholder="Felhasználónév"
          value={form.username}
          onChange={(e) => setForm({ ...form, username: e.target.value })}
        />

        <input
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />

        <input
          type="password"
          placeholder="Jelszó"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />

        <select
          value={form.role}
          onChange={(e) => setForm({ ...form, role: e.target.value })}
        >
          <option value="viewer">Viewer</option>
          <option value="admin">Admin</option>
        </select>

        <button type="submit">
          Felhasználó létrehozása
        </button>

      </form>

      <h2>Felhasználók listája</h2>

      <table>

        <thead>
          <tr>
            <th>ID</th>
            <th>Név</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>

        <tbody>

          {Array.isArray(users) && users.map((u) => (
            <tr key={u.id}>
              <td>{u.id}</td>
              <td>{u.username}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
            </tr>
          ))}

        </tbody>

      </table>

    </div>
  );
}