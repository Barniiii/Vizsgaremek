import { useEffect, useState } from 'react';
import { Plus, X, Search, Grid, List, Filter, ChevronUp, ChevronDown, Trash2, Calendar } from 'lucide-react';
import { getAnimals, addAnimal, deleteAnimal } from '../db/operations';

interface Animal {
  id: number;
  name?: string;
  species: string;
  breed?: string;
  identifier: string;
  birth_date?: string; // YYYY-MM-DD formátum
  stable?: string;
  notes?: string;
}

// Módosított SortField típus - age helyett birth_date
type SortField = 'name' | 'species' | 'breed' | 'birth_date' | 'stable';
type SortDirection = 'asc' | 'desc';

const Animals = () => {
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedSpecies, setSelectedSpecies] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [deletingId, setDeletingId] = useState<number | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    species: '',
    breed: '',
    identifier: '',
    birth_date: '',
    stable: '',
    notes: '',
  });

  // Kor kiszámítása születési dátum alapján
  const calculateAge = (birthDate: string): number => {
    const birth = new Date(birthDate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  // Kor formázása
  const formatAge = (birthDate?: string): string => {
    if (!birthDate) return 'Ismeretlen';
    
    const age = calculateAge(birthDate);
    if (age === 0) {
      // Hónapokban számoljuk, ha 1 év alatti
      const birth = new Date(birthDate);
      const today = new Date();
      const months = (today.getFullYear() - birth.getFullYear()) * 12 + 
                    (today.getMonth() - birth.getMonth());
      return `${months} hónap`;
    }
    return `${age} év`;
  };

  const loadAnimals = async () => {
    const data = await getAnimals();
    setAnimals(data as Animal[]);
  };

  useEffect(() => {
    loadAnimals();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // MÓDOSÍTOTT: csak 1 paraméter (az állat adatai)
    await addAnimal({
      name: formData.name || undefined,
      species: formData.species,
      breed: formData.breed || undefined,
      identifier: formData.identifier,
      birth_date: formData.birth_date || undefined,
      stable: formData.stable,
      notes: formData.notes,
    });
    setFormData({ 
      name: '', 
      species: '', 
      breed: '', 
      identifier: '', 
      birth_date: '', 
      stable: '', 
      notes: '' 
    });
    setShowForm(false);
    await loadAnimals();
  };

  const handleDelete = async (id: number) => {
    if (window.confirm('Biztosan törölni szeretnéd ezt az állatot?')) {
      setDeletingId(id);
      try {
        await deleteAnimal(id);
        await loadAnimals();
      } catch (error) {
        console.error('Error deleting animal:', error);
        alert('Hiba történt a törlés közben.');
      } finally {
        setDeletingId(null);
      }
    }
  };

  // Egyedi fajták kinyerése
  const uniqueSpecies = ['all', ...Array.from(new Set(animals.map(animal => animal.species)))];

  // Szűrt állatok
  const filteredAnimals = animals.filter(animal => {
    const searchLower = search.toLowerCase();
    const matchesSearch = 
      animal.name?.toLowerCase().includes(searchLower) ||
      animal.species.toLowerCase().includes(searchLower) ||
      animal.breed?.toLowerCase().includes(searchLower) ||
      animal.identifier.toLowerCase().includes(searchLower) ||
      animal.stable?.toLowerCase().includes(searchLower);
    
    const matchesSpecies = selectedSpecies === 'all' || animal.species === selectedSpecies;
    
    return matchesSearch && matchesSpecies;
  });

  // Rendezés - JAVÍTOTT: birth_date alapján rendezés
  const sortedAnimals = [...filteredAnimals].sort((a, b) => {
    let aValue: any;
    let bValue: any;

    // Speciális eset: születési dátum alapján rendezés (kor)
    if (sortField === 'birth_date') {
      aValue = a.birth_date ? calculateAge(a.birth_date) : Infinity;
      bValue = b.birth_date ? calculateAge(b.birth_date) : Infinity;
    } else {
      // Normál mezők
      aValue = a[sortField];
      bValue = b[sortField];

      // Ha a mező undefined, akkor a végére helyezzük
      if (aValue === undefined || aValue === null) return 1;
      if (bValue === undefined || bValue === null) return -1;

      // Szöveges mezők
      if (sortField === 'name' || sortField === 'species' || sortField === 'breed' || sortField === 'stable') {
        aValue = aValue.toString().toLowerCase();
        bValue = bValue.toString().toLowerCase();
      }
    }

    if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Fajta színek
  const getSpeciesColor = (species: string) => {
    const colors: Record<string, string> = {
      'Ló': 'from-amber-500 to-orange-500',
      'Tehén': 'from-purple-500 to-indigo-500',
      'Bárány': 'from-pink-500 to-rose-500',
      'Kecske': 'from-emerald-500 to-green-500',
      'Disznó': 'from-rose-500 to-pink-500',
      'Csirke': 'from-yellow-500 to-amber-500',
      'Liba': 'from-blue-500 to-cyan-500',
      'Nyúl': 'from-gray-500 to-slate-500',
      'Kutya': 'from-orange-500 to-amber-500',
      'Macska': 'from-slate-500 to-gray-500',
    };
    return colors[species] || 'from-green-500 to-emerald-500';
  };

  // Rendezési ikon
  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? <ChevronUp size={16} /> : <ChevronDown size={16} />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50 p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Fejléc */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Állatok</h1>
            <p className="text-gray-600">Állatok kezelése és nyilvántartása</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Keresés név, faj, fajta vagy istálló alapján..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 pr-4 py-2.5 w-full sm:w-64 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
              />
            </div>
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-6 py-2.5 rounded-xl transition-all duration-200 shadow-md hover:shadow-lg font-medium"
            >
              <Plus size={20} />
              Új állat
            </button>
          </div>
        </div>

        {/* Szűrők és nézet váltó */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-2 text-gray-700">
              <Filter size={20} />
              <span className="font-medium">Szűrés fajta szerint:</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  viewMode === 'grid' 
                    ? 'bg-green-100 text-green-700 border border-green-300' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Grid size={18} />
                <span>Rács</span>
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  viewMode === 'list' 
                    ? 'bg-green-100 text-green-700 border border-green-300' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <List size={18} />
                <span>Lista</span>
              </button>
            </div>
          </div>
          
          {/* Fajta szűrő gombok */}
          <div className="flex flex-wrap gap-3">
            {uniqueSpecies.map(species => (
              <button
                key={species}
                onClick={() => setSelectedSpecies(species)}
                className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                  selectedSpecies === species
                    ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white shadow-md'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 hover:border-gray-400'
                }`}
              >
                {species === 'all' ? 'Összes' : species}
                {species !== 'all' && (
                  <span className="ml-2 px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full">
                    {animals.filter(a => a.species === species).length}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Rendezés gombok - JAVÍTOTT: age helyett birth_date */}
        <div className="mb-6">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => handleSort('name')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                sortField === 'name'
                  ? 'bg-green-100 text-green-700 border border-green-300'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>Név</span>
              <SortIcon field="name" />
            </button>
            <button
              onClick={() => handleSort('species')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                sortField === 'species'
                  ? 'bg-green-100 text-green-700 border border-green-300'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>Faj</span>
              <SortIcon field="species" />
            </button>
            <button
              onClick={() => handleSort('breed')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                sortField === 'breed'
                  ? 'bg-green-100 text-green-700 border border-green-300'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>Fajta</span>
              <SortIcon field="breed" />
            </button>
            <button
              onClick={() => handleSort('birth_date')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                sortField === 'birth_date'
                  ? 'bg-green-100 text-green-700 border border-green-300'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>Kor</span>
              <SortIcon field="birth_date" />
            </button>
            <button
              onClick={() => handleSort('stable')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                sortField === 'stable'
                  ? 'bg-green-100 text-green-700 border border-green-300'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>Istálló</span>
              <SortIcon field="stable" />
            </button>
          </div>
        </div>

        {/* Modal - új állat hozzáadása */}
        {showForm && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 w-full max-w-2xl shadow-2xl">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Új állat hozzáadása</h2>
                  <p className="text-gray-500 text-sm mt-1">Töltsd ki az állat adatait</p>
                </div>
                <button
                  onClick={() => setShowForm(false)}
                  className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full p-1.5 transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-800 mb-2">Név</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="pl.: Csepp, Bütyök, Tarka"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-800 mb-2">Faj *</label>
                    <input
                      type="text"
                      value={formData.species}
                      onChange={(e) => setFormData({ ...formData, species: e.target.value })}
                      required
                      placeholder="pl.: Ló, Tehén, Csirke..."
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-800 mb-2">Fajta</label>
                    <input
                      type="text"
                      value={formData.breed}
                      onChange={(e) => setFormData({ ...formData, breed: e.target.value })}
                      placeholder="pl.: Holstein, Noniusz, Mangalica"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-800 mb-2">Azonosító *</label>
                    <input
                      type="text"
                      value={formData.identifier}
                      onChange={(e) => setFormData({ ...formData, identifier: e.target.value })}
                      required
                      placeholder="pl.: T-001, L-023, C-456"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-800 mb-2">Születési dátum</label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                      <input
                        type="date"
                        value={formData.birth_date}
                        onChange={(e) => setFormData({ ...formData, birth_date: e.target.value })}
                        max={new Date().toISOString().split('T')[0]}
                        className="w-full pl-10 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-800 mb-2">Istálló</label>
                    <input
                      type="text"
                      value={formData.stable}
                      onChange={(e) => setFormData({ ...formData, stable: e.target.value })}
                      placeholder="pl.: Istálló A, Baromfiól, Ól"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-800 mb-2">Megjegyzések</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    rows={3}
                    placeholder="Egyéb információk az állatról..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all resize-none"
                  />
                </div>
                <div className="flex gap-4 pt-2">
                  <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-6 py-3.5 rounded-xl transition-all duration-200 font-medium shadow-md hover:shadow-lg"
                  >
                    Mentés
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-3.5 rounded-xl transition-all duration-200 font-medium border border-gray-300"
                  >
                    Mégse
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Tartalom - Grid nézet */}
        {viewMode === 'grid' ? (
          <>
            {sortedAnimals.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-12 text-center">
                <div className="flex flex-col items-center justify-center">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-6">
                    <Search className="text-gray-400" size={32} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {search || selectedSpecies !== 'all' ? 'Nincs találat' : 'Még nincsenek állatok'}
                  </h3>
                  <p className="text-gray-500 max-w-md mb-6">
                    {search || selectedSpecies !== 'all'
                      ? 'Próbálj meg másik kifejezéssel keresni vagy más fajtát választani!'
                      : 'Kezdd el az állatok rögzítését a "Új állat" gombra kattintva.'}
                  </p>
                  {(search || selectedSpecies !== 'all') && (
                    <button
                      onClick={() => {
                        setSearch('');
                        setSelectedSpecies('all');
                      }}
                      className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                    >
                      Összes állat megjelenítése
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortedAnimals.map((animal) => (
                  <div
                    key={animal.id}
                    className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 relative group"
                  >
                    {/* Törlés gomb */}
                    <button
                      onClick={() => handleDelete(animal.id)}
                      disabled={deletingId === animal.id}
                      className="absolute top-4 right-4 z-10 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                      title="Állat törlése"
                    >
                      {deletingId === animal.id ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Trash2 size={16} />
                      )}
                    </button>

                    {/* Kártya fejléc */}
                    <div className={`h-2 bg-gradient-to-r ${getSpeciesColor(animal.species)}`} />
                    <div className="p-6">
                      {/* Név és fajta - JÓL LÁTHATÓAN */}
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex-1">
                          {animal.name && (
                            <h3 className="text-2xl font-bold text-gray-900 mb-1 truncate" title={animal.name}>
                              {animal.name}
                            </h3>
                          )}
                          <div className="flex flex-col gap-2">
                            <div className="flex flex-wrap gap-2 items-center">
                              <span className="text-lg font-semibold text-gray-700">{animal.species}</span>
                              {animal.breed && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
                                  {animal.breed}
                                </span>
                              )}
                            </div>
                            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800 w-fit">
                              {animal.identifier}
                            </span>
                          </div>
                        </div>
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center flex-shrink-0 ml-3">
                          <span className="text-gray-700 font-bold text-lg">
                            {animal.name ? animal.name.charAt(0) : animal.species.charAt(0)}
                          </span>
                        </div>
                      </div>

                      {/* Adatok */}
                      <div className="space-y-4">
                        <div className="flex items-center">
  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
    <i className="fa-solid fa-calendar text-green-600"></i>
  </div>
                          <div>
                            <p className="text-sm text-gray-500">Kor</p>
                            <p className="font-medium text-gray-900">
                              {formatAge(animal.birth_date)}
                            </p>
                            {animal.birth_date && (
                              <p className="text-xs text-gray-400 mt-0.5">
                                Született: {new Date(animal.birth_date).toLocaleDateString('hu-HU')}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center">
  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
    <i className="fa-solid fa-house text-blue-600"></i>
  </div>
                          <div>
                            <p className="text-sm text-gray-500">Istálló</p>
                            <p className="font-medium text-gray-900">
                              {animal.stable || 'Nincs megadva'}
                            </p>
                          </div>
                        </div>

                        {animal.notes && (
                          <div className="pt-4 border-t border-gray-100">
                            <p className="text-sm text-gray-500 mb-1">Megjegyzések</p>
                            <p className="text-sm text-gray-700 line-clamp-2">
                              {animal.notes}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          /* Lista nézet - JAVÍTOTT: age helyett birth_date */
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-green-50 to-emerald-50">
                  <tr>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      <button 
                        onClick={() => handleSort('name')}
                        className="flex items-center gap-1 hover:text-green-700"
                      >
                        Név
                        <SortIcon field="name" />
                      </button>
                    </th>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      <button 
                        onClick={() => handleSort('species')}
                        className="flex items-center gap-1 hover:text-green-700"
                      >
                        Faj
                        <SortIcon field="species" />
                      </button>
                    </th>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      <button 
                        onClick={() => handleSort('breed')}
                        className="flex items-center gap-1 hover:text-green-700"
                      >
                        Fajta
                        <SortIcon field="breed" />
                      </button>
                    </th>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      Azonosító
                    </th>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      <button 
                        onClick={() => handleSort('birth_date')}
                        className="flex items-center gap-1 hover:text-green-700"
                      >
                        Kor
                        <SortIcon field="birth_date" />
                      </button>
                    </th>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      <button 
                        onClick={() => handleSort('stable')}
                        className="flex items-center gap-1 hover:text-green-700"
                      >
                        Istálló
                        <SortIcon field="stable" />
                      </button>
                    </th>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      Megjegyzések
                    </th>
                    <th className="px-8 py-4 text-left text-sm font-semibold text-gray-800 uppercase tracking-wider border-b border-gray-300">
                      Műveletek
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {sortedAnimals.map((animal, index) => (
                    <tr
                      key={animal.id}
                      className={`hover:bg-green-50/50 transition-colors ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}
                    >
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${getSpeciesColor(animal.species)} flex items-center justify-center`}>
                            <span className="text-white font-medium text-sm">
                              {animal.name ? animal.name.charAt(0) : animal.species.charAt(0)}
                            </span>
                          </div>
                          <div>
                            {animal.name && (
                              <div className="font-medium text-gray-900">{animal.name}</div>
                            )}
                            <div className="text-sm text-gray-500">{animal.species}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <span className="font-medium text-gray-900">{animal.species}</span>
                      </td>
                      <td className="px-8 py-5">
                        <span className={`font-medium ${animal.breed ? 'text-gray-900' : 'text-gray-400'}`}>
                          {animal.breed || '-'}
                        </span>
                      </td>
                      <td className="px-8 py-5">
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                          {animal.identifier}
                        </span>
                      </td>
                      <td className="px-8 py-5">
                        <div className="flex flex-col">
                          <span className={`font-medium ${animal.birth_date ? 'text-gray-900' : 'text-gray-400'}`}>
                            {formatAge(animal.birth_date)}
                          </span>
                          {animal.birth_date && (
                            <span className="text-xs text-gray-400">
                              {new Date(animal.birth_date).toLocaleDateString('hu-HU')}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <span className={`font-medium ${animal.stable ? 'text-gray-900' : 'text-gray-400'}`}>
                          {animal.stable || '-'}
                        </span>
                      </td>
                      <td className="px-8 py-5">
                        <span className={`text-sm ${animal.notes ? 'text-gray-700' : 'text-gray-400'}`}>
                          {animal.notes ? (animal.notes.length > 30 ? `${animal.notes.substring(0, 30)}...` : animal.notes) : '-'}
                        </span>
                      </td>
                      <td className="px-8 py-5">
                        <button
                          onClick={() => handleDelete(animal.id)}
                          disabled={deletingId === animal.id}
                          className="w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-lg flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title="Törlés"
                        >
                          {deletingId === animal.id ? (
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <Trash2 size={16} />
                          )}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Összegzés - JAVÍTOTT: birth_date helyes megjelenítése */}
        {animals.length > 0 && (
          <div className="mt-8 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border border-green-100">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Statisztika</h4>
                <p className="text-sm text-gray-600">
                  Összesen <span className="font-semibold text-green-700">{sortedAnimals.length}</span> állat
                  {search && <span> a(z) "<span className="font-semibold">{search}</span>" keresésre</span>}
                  {selectedSpecies !== 'all' && <span> a(z) "<span className="font-semibold">{selectedSpecies}</span>" fajtából</span>}
                  <span> | Rendezve: <span className="font-semibold">
                    {sortField === 'name' && 'Név'}
                    {sortField === 'species' && 'Faj'}
                    {sortField === 'breed' && 'Fajta'}
                    {sortField === 'birth_date' && 'Kor'}
                    {sortField === 'stable' && 'Istálló'}
                  </span> ({sortDirection === 'asc' ? 'növekvő' : 'csökkenő'})</span>
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                {uniqueSpecies
                  .filter(s => s !== 'all')
                  .map(species => (
                    <span key={species} className="px-3 py-1 bg-white border border-gray-300 rounded-full text-sm text-gray-700">
                      {species}: <span className="font-semibold">{animals.filter(a => a.species === species).length}</span>
                    </span>
                  ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Animals;