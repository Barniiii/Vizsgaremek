import { apiRequest } from '../api/http';

// NOTE: old local sql.js DB was replaced by API calls.
// The pages still import these helpers, so we keep the same function names.

function getToken(): string | null {
  return localStorage.getItem('bbagrar_token');
}

export const getAnimalCount = async () => {
  const token = getToken();
  const data = await apiRequest<{ animalCount: number }>('/api/dashboard/stats', { token });
  return data.animalCount;
};

export const getBalance = async () => {
  const token = getToken();
  const data = await apiRequest<{ balance: number }>('/api/dashboard/stats', { token });
  return data.balance;
};

export const getAnimals = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/animals', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching animals:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addAnimal = async (
  animal: { 
    name?: string; 
    species: string; 
    breed?: string; 
    identifier: string; 
    birth_date?: string;  // YYYY-MM-DD formátum
    stable?: string; 
    notes?: string 
  }
) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/animals', { 
      method: 'POST', 
      token, 
      body: animal 
    });
    return response;
  } catch (error) {
    console.error('Error adding animal:', error);
    throw error;
  }
};

export const deleteAnimal = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest(`/api/animals/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting animal:', error);
    throw error;
  }
};

// Lands
export const getLands = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/lands', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching lands:', error);
    return [];
  }
};

export const deleteLand = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest(`/api/lands/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting land:', error);
    throw error;
  }
};

export const addLand = async (land: { 
  name: string; 
  plot_number?: string; 
  area: number;
  city?: string;
  ownership_type: 'owned' | 'rented';
  status?: string;
  notes?: string;
}) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/lands', { 
      method: 'POST', 
      token, 
      body: land 
    });
    return response;
  } catch (error) {
    console.error('Error adding land:', error);
    throw error;
  }
};

export const getExpenses = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/expenses', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching expenses:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addExpense = async (expense: { amount: number; category: string; description?: string; date: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/expenses', { 
      method: 'POST', 
      token, 
      body: expense 
    });
    return response;
  } catch (error) {
    console.error('Error adding expense:', error);
    throw error;
  }
};

export const deleteExpense = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest(`/api/expenses/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting expense:', error);
    throw error;
  }
};

export const getIncomes = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/incomes', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching incomes:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addIncome = async (income: { amount: number; category: string; description?: string; date: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/incomes', { 
      method: 'POST', 
      token, 
      body: income 
    });
    return response;
  } catch (error) {
    console.error('Error adding income:', error);
    throw error;
  }
};

export const deleteIncome = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest(`/api/incomes/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting income:', error);
    throw error;
  }
};

export const getClients = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/clients', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching clients:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addClient = async (client: { name: string; email?: string; phone?: string; type?: string; notes?: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/clients', { 
      method: 'POST', 
      token, 
      body: client 
    });
    return response;
  } catch (error) {
    console.error('Error adding client:', error);
    throw error;
  }
};

export const deleteClient = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest(`/api/clients/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting client:', error);
    throw error;
  }
};

export const getMarketplace = async () => {
  try {
    const data = await apiRequest<{ items: any[] }>('/api/marketplace');
    return data.items;
  } catch (error) {
    console.error('Error fetching marketplace items:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addMarketplaceItem = async (item: { title: string; description?: string; type: string; price: number; image_url?: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/marketplace', { 
      method: 'POST', 
      token, 
      body: item 
    });
    return response;
  } catch (error) {
    console.error('Error adding marketplace item:', error);
    throw error;
  }
};

export const deleteMarketplaceItem = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest(`/api/marketplace/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting marketplace item:', error);
    throw error;
  }
};

export const getDocuments = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/documents', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching documents:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addDocument = async (doc: { title: string; category: string; filename: string; filepath: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/documents', { 
      method: 'POST', 
      token, 
      body: doc 
    });
    return response;
  } catch (error) {
    console.error('Error adding document:', error);
    throw error;
  }
};

export const deleteDocument = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest(`/api/documents/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting document:', error);
    throw error;
  }
};