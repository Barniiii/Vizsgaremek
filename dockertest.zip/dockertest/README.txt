Inditás:
backend
cd server
npm install
npm run dev

frontend
cd dockertest
npm install
npm run dev