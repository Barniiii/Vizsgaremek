import { useEffect, useState } from 'react';
import { Plus, X, TrendingUp, TrendingDown, Edit2, Trash2, PieChart, BarChart3, LayoutGrid, List, Calendar, Tag } from 'lucide-react';
import { 
  getExpenses, 
  getIncomes, 
  addExpense, 
  addIncome, 
  getBalance, 
  deleteExpense, 
  deleteIncome 
} from '../db/operations';

interface Transaction {
  id: number;
  user_id?: number;
  amount: number;
  category: string;
  description?: string | null;
  date: string;
  created_at?: string;
}

// Segédfüggvény a számok formázásához
const formatCurrency = (value: number): string => {
  if (typeof value !== 'number' || isNaN(value)) {
    return '0 Ft';
  }
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' Ft';
};

// Relatív dátum formázás
const formatRelativeDate = (dateString: string): string => {
  const date = new Date(dateString);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  if (date.toDateString() === today.toDateString()) return 'Ma';
  if (date.toDateString() === yesterday.toDateString()) return 'Tegnap';
  
  const diffTime = today.getTime() - date.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays < 7) return `${diffDays} napja`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} hete`;
  
  return date.toLocaleDateString('hu-HU', { month: 'short', day: 'numeric' });
};

// Kategória szín generálás
const getCategoryColor = (category: string, type: 'expense' | 'income'): string => {
  const expenseColors: Record<string, string> = {
    'Takarmány': 'bg-amber-100 text-amber-800 border-amber-200',
    'Állatorvos': 'bg-red-100 text-red-800 border-red-200',
    'Gyógyszer': 'bg-rose-100 text-rose-800 border-rose-200',
    'Üzemanyag': 'bg-orange-100 text-orange-800 border-orange-200',
    'Bér': 'bg-blue-100 text-blue-800 border-blue-200',
    'Villany': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    'Víz': 'bg-cyan-100 text-cyan-800 border-cyan-200',
    'Egyéb': 'bg-gray-100 text-gray-800 border-gray-200',
  };
  
  const incomeColors: Record<string, string> = {
    'Értékesítés': 'bg-emerald-100 text-emerald-800 border-emerald-200',
    'Támogatás': 'bg-green-100 text-green-800 border-green-200',
    'Bérleti díj': 'bg-teal-100 text-teal-800 border-teal-200',
    'Egyéb': 'bg-gray-100 text-gray-800 border-gray-200',
  };
  
  const colors = type === 'expense' ? expenseColors : incomeColors;
  return colors[category] || (type === 'expense' ? 'bg-red-50 text-red-700 border-red-200' : 'bg-green-50 text-green-700 border-green-200');
};

const Budget = () => {
  const [expenses, setExpenses] = useState<Transaction[]>([]);
  const [incomes, setIncomes] = useState<Transaction[]>([]);
  const [balance, setBalance] = useState(0);
  const [activeTab, setActiveTab] = useState<'expenses' | 'incomes'>('expenses');
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showChart, setShowChart] = useState(false);
  const [loading, setLoading] = useState(true);
  const [useExistingCategory, setUseExistingCategory] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    category: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [expensesData, incomesData, balanceData] = await Promise.all([
        getExpenses(),
        getIncomes(),
        getBalance()
      ]);
      
      setExpenses(expensesData as Transaction[]);
      setIncomes(incomesData as Transaction[]);
      setBalance(Number(balanceData));
    } catch (error) {
      console.error('Hiba az adatok betöltésekor:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const data = {
        amount: parseFloat(formData.amount),
        category: formData.category,
        description: formData.description || undefined,
        date: formData.date,
      };

      if (editingId) {
        alert('Szerkesztés még nem elérhető!');
        return;
      } else {
        if (activeTab === 'expenses') {
          await addExpense(data);
        } else {
          await addIncome(data);
        }
      }

      resetForm();
      await loadData();
    } catch (error) {
      console.error('Hiba a mentés során:', error);
      alert('Hiba történt a mentés során!');
    }
  };

  const handleDelete = async (id: number, type: 'expense' | 'income') => {
    if (!confirm('Biztosan törölni szeretnéd ezt a tételt?')) return;

    try {
      if (type === 'expense') {
        await deleteExpense(id);
      } else {
        await deleteIncome(id);
      }
      await loadData();
    } catch (error) {
      console.error('Hiba a törlés során:', error);
      alert('Hiba történt a törlés során!');
    }
  };

  const handleEdit = (item: Transaction) => {
    setFormData({
      amount: item.amount.toString(),
      category: item.category,
      description: item.description || '',
      date: item.date,
    });
    setEditingId(item.id);
    setShowForm(true);
    setUseExistingCategory(true);
  };

  const resetForm = () => {
    setFormData({ 
      amount: '', 
      category: '', 
      description: '', 
      date: new Date().toISOString().split('T')[0] 
    });
    setEditingId(null);
    setShowForm(false);
    setUseExistingCategory(false);
  };

  const totalExpenses = expenses.reduce((sum, exp) => sum + (Number(exp.amount) || 0), 0);
  const totalIncomes = incomes.reduce((sum, inc) => sum + (Number(inc.amount) || 0), 0);

  const expenseCategories = [...new Set(expenses.map(e => e.category))];
  const incomeCategories = [...new Set(incomes.map(i => i.category))];
  const currentCategories = activeTab === 'expenses' ? expenseCategories : incomeCategories;
  const currentItems = activeTab === 'expenses' ? expenses : incomes;

  // Adatok rendezése dátum szerint (legfrissebb elöl)
  const sortedItems = [...currentItems].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Adatok betöltése...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Fejléc */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Költségvetés</h1>
          <p className="text-gray-500 mt-1">Kiadások és bevételek kezelése</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowChart(!showChart)}
            className="flex items-center gap-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-xl transition-all shadow-sm"
          >
            {showChart ? <BarChart3 size={18} /> : <PieChart size={18} />}
            <span className="hidden sm:inline">{showChart ? 'Lista' : 'Diagram'}</span>
          </button>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl transition-all shadow-md hover:shadow-lg"
          >
            <Plus size={18} />
            <span className="hidden sm:inline">Új tétel</span>
          </button>
        </div>
      </div>

      {/* Statisztika kártyák */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 bg-gradient-to-br from-green-100 to-emerald-100 text-green-700 rounded-xl">
              <TrendingUp size={24} />
            </div>
            <div>
              <p className="text-gray-500 text-sm font-medium">Bevételek</p>
              <p className="text-xs text-gray-400">{incomes.length} tétel</p>
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalIncomes)}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 bg-gradient-to-br from-red-100 to-rose-100 text-red-700 rounded-xl">
              <TrendingDown size={24} />
            </div>
            <div>
              <p className="text-gray-500 text-sm font-medium">Kiadások</p>
              <p className="text-xs text-gray-400">{expenses.length} tétel</p>
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalExpenses)}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-3">
            <div className={`p-3 rounded-xl ${balance >= 0 ? 'bg-gradient-to-br from-green-100 to-emerald-100 text-green-700' : 'bg-gradient-to-br from-red-100 to-rose-100 text-red-700'}`}>
              <TrendingUp size={24} className={balance < 0 ? 'rotate-180' : ''} />
            </div>
            <div>
              <p className="text-gray-500 text-sm font-medium">Egyenleg</p>
              <p className="text-xs text-gray-400">{balance >= 0 ? 'Pozitív' : 'Negatív'}</p>
            </div>
          </div>
          <p className={`text-2xl font-bold ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(balance)}
          </p>
        </div>
      </div>

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">
                {editingId ? 'Tétel szerkesztése' : 'Új tétel hozzáadása'}
              </h2>
              <button onClick={resetForm} className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded-lg transition-colors">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Típus</label>
                <select
                  value={activeTab}
                  onChange={(e) => {
                    setActiveTab(e.target.value as 'expenses' | 'incomes');
                    setUseExistingCategory(false);
                  }}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                >
                  <option value="expenses">Kiadás</option>
                  <option value="incomes">Bevétel</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Összeg (Ft) *</label>
                <div className="relative">
                  <input
                    type="number"
                    step="1"
                    min="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent pl-4"
                    placeholder="0"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm">Ft</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-sm font-medium text-gray-700">Kategória *</label>
                  {currentCategories.length > 0 && !editingId && (
                    <button
                      type="button"
                      onClick={() => setUseExistingCategory(!useExistingCategory)}
                      className="text-xs text-green-600 hover:text-green-800 font-medium"
                    >
                      {useExistingCategory ? 'Új kategória' : 'Meglévő kategória'}
                    </button>
                  )}
                </div>
                
                {useExistingCategory && currentCategories.length > 0 ? (
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                  >
                    <option value="">Válassz kategóriát</option>
                    {currentCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                    placeholder={activeTab === 'expenses' ? "pl.: Takarmány, Állatorvos..." : "pl.: Értékesítés, Támogatás..."}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Leírás</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Részletek..."
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Dátum *</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              
              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2.5 rounded-xl transition-colors font-medium shadow-md hover:shadow-lg"
                >
                  {editingId ? 'Módosítás' : 'Mentés'}
                </button>
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2.5 rounded-xl transition-colors font-medium"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Fő tartalom */}
      {!showChart && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          {/* Tab és nézetváltó fejléc */}
          <div className="border-b border-gray-100">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-4 gap-4">
              <div className="flex bg-gray-100 p-1 rounded-xl">
                <button
                  onClick={() => setActiveTab('expenses')}
                  className={`flex-1 sm:flex-none px-6 py-2 text-sm font-medium rounded-lg transition-all ${
                    activeTab === 'expenses'
                      ? 'bg-white text-red-600 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <TrendingDown size={16} />
                    Kiadások
                    <span className="bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full text-xs">{expenses.length}</span>
                  </span>
                </button>
                <button
                  onClick={() => setActiveTab('incomes')}
                  className={`flex-1 sm:flex-none px-6 py-2 text-sm font-medium rounded-lg transition-all ${
                    activeTab === 'incomes'
                      ? 'bg-white text-green-600 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <TrendingUp size={16} />
                    Bevételek
                    <span className="bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full text-xs">{incomes.length}</span>
                  </span>
                </button>
              </div>

              {/* Nézetváltó */}
              <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-xl self-start sm:self-auto">
                <button
                  onClick={() => setViewMode('card')}
                  className={`p-2 rounded-lg transition-all ${
                    viewMode === 'card' 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                  title="Kártyás nézet"
                >
                  <LayoutGrid size={18} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg transition-all ${
                    viewMode === 'list' 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                  title="Listás nézet"
                >
                  <List size={18} />
                </button>
              </div>
            </div>
          </div>

          {/* Tartalom */}
          <div className="p-4 sm:p-6">
            {sortedItems.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  {activeTab === 'expenses' ? (
                    <TrendingDown size={32} className="text-gray-400" />
                  ) : (
                    <TrendingUp size={32} className="text-gray-400" />
                  )}
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">
                  Még nincsenek {activeTab === 'expenses' ? 'kiadások' : 'bevételek'}
                </h3>
                <p className="text-gray-500 mb-4">Adj hozzá új tételt a kezdéshez</p>
                <button
                  onClick={() => setShowForm(true)}
                  className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium"
                >
                  <Plus size={18} />
                  Új tétel hozzáadása
                </button>
              </div>
            ) : (
              <>
                {/* Kártyás nézet */}
                {viewMode === 'card' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {sortedItems.map((item, index) => (
                      <div 
                        key={item.id} 
                        className="group bg-white border border-gray-200 rounded-xl p-5 hover:shadow-lg hover:border-gray-300 transition-all duration-200"
                        style={{ animationDelay: `${index * 50}ms` }}
                      >
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center gap-2">
                            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${getCategoryColor(item.category, activeTab)}`}>
                              <Tag size={12} className="mr-1" />
                              {item.category}
                            </span>
                          </div>
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => handleEdit(item)}
                              className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              title="Szerkesztés"
                            >
                              <Edit2 size={16} />
                            </button>
                            <button
                              onClick={() => handleDelete(item.id, activeTab === 'expenses' ? 'expense' : 'income')}
                              className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              title="Törlés"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>

                        <div className="mb-3">
                          <p className="text-2xl font-bold text-gray-900">
                            {formatCurrency(Number(item.amount))}
                          </p>
                          {item.description && (
                            <p className="text-gray-500 text-sm mt-1 line-clamp-2">{item.description}</p>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-sm text-gray-400 pt-3 border-t border-gray-100">
                          <Calendar size={14} />
                          <span>{formatRelativeDate(item.date)}</span>
                          <span className="text-gray-300">•</span>
                          <span>{new Date(item.date).toLocaleDateString('hu-HU')}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Listás nézet */}
                {viewMode === 'list' && (
                  <div className="space-y-2">
                    {sortedItems.map((item, index) => (
                      <div 
                        key={item.id}
                        className="group flex items-center gap-4 p-4 bg-white border border-gray-200 rounded-xl hover:shadow-md hover:border-gray-300 transition-all duration-200"
                        style={{ animationDelay: `${index * 30}ms` }}
                      >
                        {/* Dátum */}
                        <div className="flex-shrink-0 w-16 text-center">
                          <div className="text-xs text-gray-400 uppercase font-medium">
                            {new Date(item.date).toLocaleDateString('hu-HU', { month: 'short' })}
                          </div>
                          <div className="text-lg font-bold text-gray-900">
                            {new Date(item.date).getDate()}
                          </div>
                        </div>

                        {/* Kategória és leírás */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-semibold border ${getCategoryColor(item.category, activeTab)}`}>
                              {item.category}
                            </span>
                            {formatRelativeDate(item.date) !== new Date(item.date).toLocaleDateString('hu-HU') && (
                              <span className="text-xs text-gray-400">{formatRelativeDate(item.date)}</span>
                            )}
                          </div>
                          {item.description && (
                            <p className="text-gray-500 text-sm truncate">{item.description}</p>
                          )}
                        </div>

                        {/* Összeg */}
                        <div className="flex-shrink-0 text-right">
                          <p className="text-lg font-bold text-gray-900">
                            {formatCurrency(Number(item.amount))}
                          </p>
                        </div>

                        {/* Műveletek */}
                        <div className="flex-shrink-0 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => handleEdit(item)}
                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Szerkesztés"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => handleDelete(item.id, activeTab === 'expenses' ? 'expense' : 'income')}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Törlés"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* Diagram nézet */}
      {showChart && activeTab === 'expenses' && expenses.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Kiadások megoszlása kategóriánként</h2>
          <div className="space-y-4">
            {Object.entries(
              expenses.reduce((acc, exp) => {
                acc[exp.category] = (acc[exp.category] || 0) + Number(exp.amount);
                return acc;
              }, {} as Record<string, number>)
            )
              .sort((a, b) => b[1] - a[1])
              .map(([category, amount], index) => {
                const percentage = (amount / totalExpenses) * 100;
                const colors = [
                  'bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-yellow-500', 
                  'bg-lime-500', 'bg-green-500', 'bg-emerald-500', 'bg-teal-500'
                ];
                const colorClass = colors[index % colors.length];
                
                return (
                  <div key={category} className="group">
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center gap-3">
                        <span className={`w-3 h-3 rounded-full ${colorClass}`}></span>
                        <span className="font-medium text-gray-900">{category}</span>
                        <span className="text-sm text-gray-500">{formatCurrency(amount)}</span>
                      </div>
                      <span className="font-bold text-gray-900">{percentage.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                      <div
                        className={`${colorClass} h-full rounded-full transition-all duration-500 ease-out group-hover:opacity-80`}
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
          </div>
          
          {/* Összesítés */}
          <div className="mt-8 pt-6 border-t border-gray-100">
            <div className="flex justify-between items-center">
              <span className="text-gray-500">Összes kiadás</span>
              <span className="text-2xl font-bold text-gray-900">{formatCurrency(totalExpenses)}</span>
            </div>
          </div>
        </div>
      )}

      {showChart && activeTab === 'expenses' && expenses.length === 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <PieChart size={32} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">Nincs megjeleníthető adat</h3>
          <p className="text-gray-500">Adj hozzá kiadásokat a diagram megtekintéséhez</p>
        </div>
      )}

      {showChart && activeTab === 'incomes' && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <BarChart3 size={32} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">Diagram csak kiadásokhoz</h3>
          <p className="text-gray-500 mb-4">Válts a kiadások fülre a vizualizáció megtekintéséhez</p>
          <button
            onClick={() => setActiveTab('expenses')}
            className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium"
          >
            <TrendingDown size={18} />
            Váltás kiadásokra
          </button>
        </div>
      )}
    </div>
  );
};

export default Budget;