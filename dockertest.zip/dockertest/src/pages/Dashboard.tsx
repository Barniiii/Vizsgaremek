import { useEffect, useState } from 'react';
import { Beef, DollarSign, Calendar, TrendingUp, Clock, AlertCircle } from 'lucide-react';
import { getAnimalCount, getBalance } from '../db/operations';
import { getEventsByDate, getUpcomingEvents, CalendarEventWithAnimal } from '../db/calendaroperations';

interface DashboardStats {
  animalCount: number;
  balance: number;
  todayEvents: CalendarEventWithAnimal[];
  tomorrowEvents: CalendarEventWithAnimal[];
  upcomingCount: number;
}

const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    animalCount: 0,
    balance: 0,
    todayEvents: [],
    tomorrowEvents: [],
    upcomingCount: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      // Alap statisztikák betöltése
      const [animalCount, balance] = await Promise.all([
        getAnimalCount(),
        getBalance()
      ]);

      // Mai dátum
      const today = new Date().toISOString().split('T')[0];
      
      // Holnapi dátum
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      // Események betöltése
      const [todayEvents, tomorrowEvents, upcoming] = await Promise.all([
        getEventsByDate(today),
        getEventsByDate(tomorrowStr),
        getUpcomingEvents(7)
      ]);

      setStats({
        animalCount: Number(animalCount),
        balance: Number(balance),
        todayEvents,
        tomorrowEvents,
        upcomingCount: upcoming.length,
      });
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Idő formázása
  const formatTime = (time?: string) => {
    if (!time) return '';
    return time.substring(0, 5);
  };

  // Prioritás színének meghatározása
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-700 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-700 border-green-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  // Esemény típus ikon
  const getEventIcon = (type: string) => {
    switch (type) {
      case 'task': return '📋';
      case 'appointment': return '📅';
      case 'feeding': return '🥕';
      case 'vet': return '🏥';
      case 'harvest': return '🌾';
      default: return '📌';
    }
  };

  const statCards = [
    {
      icon: Beef,
      label: 'Állatlétszám',
      value: stats.animalCount,
      color: 'bg-green-100 text-green-700',
    },
    {
      icon: DollarSign,
      label: 'Pénzügyi egyenleg',
      value: `${stats.balance.toLocaleString('hu-HU')} Ft`,
      color: 'bg-green-100 text-green-700',
    },
    {
      icon: Calendar,
      label: 'Közelgő események',
      value: stats.upcomingCount,
      color: 'bg-green-100 text-green-700',
    },
    {
      icon: TrendingUp,
      label: 'Mai teendők',
      value: stats.todayEvents.length,
      color: 'bg-green-100 text-green-700',
    },
  ];

  // Események megjelenítése
  const renderEvents = (events: CalendarEventWithAnimal[], title: string) => {
    if (events.length === 0) {
      return (
        <div className="text-center py-6 bg-gray-50 rounded-lg">
          <AlertCircle className="mx-auto text-gray-400 mb-2" size={24} />
          <p className="text-gray-500">Nincs esemény</p>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {events.slice(0, 3).map(event => (
          <div
            key={event.id}
            className={`p-3 rounded-lg border-l-4 ${getPriorityColor(event.priority)}`}
            style={{ borderLeftColor: event.color || undefined }}
          >
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{getEventIcon(event.event_type)}</span>
                  <h4 className="font-medium text-gray-900">{event.title}</h4>
                </div>
                <div className="flex items-center gap-3 mt-1 text-xs text-gray-600">
                  {event.event_time && (
                    <span className="flex items-center gap-1">
                      <Clock size={12} />
                      {formatTime(event.event_time)}
                    </span>
                  )}
                  {event.animal_name && (
                    <span className="bg-white bg-opacity-50 px-2 py-0.5 rounded-full">
                      {event.animal_name}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        {events.length > 3 && (
          <p className="text-sm text-gray-500 text-center mt-2">
            +{events.length - 3} további esemény
          </p>
        )}
      </div>
    );
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>

      {/* Statisztika kártyák */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${card.color}`}>
                  <Icon size={24} />
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-1">{card.label}</p>
              <p className="text-2xl font-bold text-gray-800">
                {loading ? (
                  <span className="text-gray-400">Betöltés...</span>
                ) : (
                  card.value
                )}
              </p>
            </div>
          );
        })}
      </div>

      {/* Események grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Mai események */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Mai események</h2>
            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
              {stats.todayEvents.length} db
            </span>
          </div>
          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-green-500 border-t-transparent"></div>
            </div>
          ) : (
            renderEvents(stats.todayEvents, 'Mai események')
          )}
        </div>

        {/* Holnapi események */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Holnapi események</h2>
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              {stats.tomorrowEvents.length} db
            </span>
          </div>
          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-green-500 border-t-transparent"></div>
            </div>
          ) : (
            renderEvents(stats.tomorrowEvents, 'Holnapi események')
          )}
        </div>
      </div>

      {/* Gyors műveletek és további infók */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Legutóbbi tevékenységek</h2>
          <div className="space-y-3">
            {stats.todayEvents.length > 0 ? (
              stats.todayEvents.slice(0, 3).map(event => (
                <div key={event.id} className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <span className="text-lg">{getEventIcon(event.event_type)}</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{event.title}</p>
                    <p className="text-sm text-gray-500">
                      Ma {event.event_time ? formatTime(event.event_time) : ''}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-600">Nincsenek legutóbbi tevékenységek</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Gyors műveletek</h2>
          <div className="space-y-3">
            <button 
              onClick={() => window.location.href = '/animals?action=new'}
              className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Új állat hozzáadása
            </button>
            <button 
              onClick={() => window.location.href = '/expenses?action=new'}
              className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Új kiadás rögzítése
            </button>
            <button 
              onClick={() => window.location.href = '/incomes?action=new'}
              className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Új bevétel rögzítése
            </button>
            <button 
              onClick={() => window.location.href = '/calendar'}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Naptár megnyitása
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;