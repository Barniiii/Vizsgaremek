import { useEffect, useState } from 'react';
import { Beef, DollarSign, Calendar, TrendingUp } from 'lucide-react';
import { getAnimalCount, getBalance } from '../db/operations';

const Dashboard = () => {
  const [stats, setStats] = useState({
    animalCount: 0,
    balance: 0,
  });

  useEffect(() => {
    const loadStats = async () => {
      const animalCount = await getAnimalCount();
      const balance = await getBalance();
      setStats({
        animalCount: Number(animalCount),
        balance: Number(balance),
      });
    };
    loadStats();
  }, []);

  const statCards = [
    {
      icon: Beef,
      label: 'Állatlétszám',
      value: stats.animalCount,
      color: 'bg-green-100 text-green-700',
    },
    {
      icon: DollarSign,
      label: 'Pénzügyi egyenleg',
      value: `${stats.balance.toLocaleString('hu-HU')} Ft`,
      color: 'bg-green-100 text-green-700',
    },
    {
      icon: Calendar,
      label: 'Közelgő feladatok',
      value: 0,
      color: 'bg-green-100 text-green-700',
    },
    {
      icon: TrendingUp,
      label: 'Havi növekedés',
      value: '0%',
      color: 'bg-green-100 text-green-700',
    },
  ];

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${card.color}`}>
                  <Icon size={24} />
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-1">{card.label}</p>
              <p className="text-2xl font-bold text-gray-800">{card.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Legutóbbi tevékenységek</h2>
          <div className="space-y-3">
            <p className="text-gray-600">Nincsenek legutóbbi tevékenységek</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Gyors műveletek</h2>
          <div className="space-y-3">
            <button className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
              Új állat hozzáadása
            </button>
            <button className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
              Új kiadás rögzítése
            </button>
            <button className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
              Új bevétel rögzítése
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
