import { ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Beef, Map, FileText, DollarSign, Users, ShoppingCart } from 'lucide-react';
import { useAuth } from '../auth/AuthContext';

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/animals', icon: Beef, label: 'Állatok' },
    { path: '/lands', icon: Map, label: 'Földek' },
    { path: '/budget', icon: DollarSign, label: 'Költségvetés' },
    { path: '/clients', icon: Users, label: 'Ügyfelek' },
    { path: '/documents', icon: FileText, label: 'Dokumentáció' },
    { path: '/marketplace', icon: ShoppingCart, label: 'Piactér' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <aside className="w-64 bg-green-700 text-white flex flex-col">
        <div className="p-6 border-b border-green-600">
          <h1 className="text-2xl font-bold">AgárAdmin</h1>
          <p className="text-sm text-green-100 mt-1">Mezőgazdasági rendszer</p>
        </div>

        <nav className="flex-1 p-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${
                  isActive
                    ? 'bg-green-800 text-white'
                    : 'text-green-50 hover:bg-green-600'
                }`}
              >
                <Icon size={20} />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-green-600">
          <p className="text-sm text-green-100">Bejelentkezve: {user?.username || '-'}</p>
          <button
            onClick={() => {
              logout();
              navigate('/login', { replace: true });
            }}
            className="mt-3 w-full bg-green-800 hover:bg-green-900 text-white px-4 py-2 rounded-lg transition-colors"
          >
            Kilépés
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
