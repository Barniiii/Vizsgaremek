// pages/Users.tsx
import { useEffect, useState } from "react";
import { useTheme } from '../context/ThemeContext';

interface User {
  id: number;
  username: string;
  email: string;
  password?: string;
  role: "viewer" | "admin" | "owner";
}

export default function Users() {
  const { isDarkMode } = useTheme();
  const [users, setUsers] = useState<User[]>([]);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    role: "viewer" as "viewer" | "admin" | "owner"
  });

  const token = localStorage.getItem("token");

  const styles = {
    container: {
      maxWidth: "1200px",
      margin: "0 auto",
      padding: "2rem",
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      backgroundColor: isDarkMode ? "#1a202c" : "#f5f7fa",
      minHeight: "100vh",
      color: isDarkMode ? "#e2e8f0" : "inherit"
    },
    title: {
      color: isDarkMode ? "#f7fafc" : "#2c3e50",
      fontSize: "2.5rem",
      marginBottom: "2rem",
      textAlign: "center" as const,
      fontWeight: "600"
    },
    formContainer: {
      backgroundColor: isDarkMode ? "#2d3748" : "white",
      padding: "2rem",
      borderRadius: "12px",
      boxShadow: isDarkMode ? "0 4px 6px rgba(0, 0, 0, 0.3)" : "0 4px 6px rgba(0, 0, 0, 0.1)",
      marginBottom: "2rem"
    },
    formTitle: {
      color: isDarkMode ? "#f7fafc" : "#34495e",
      fontSize: "1.5rem",
      marginBottom: "1.5rem",
      fontWeight: "500"
    },
    inputGroup: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
      gap: "1rem",
      marginBottom: "1rem"
    },
    input: {
      padding: "0.75rem",
      border: isDarkMode ? "2px solid #4a5568" : "2px solid #e0e0e0",
      borderRadius: "8px",
      fontSize: "1rem",
      transition: "border-color 0.3s ease",
      outline: "none",
      backgroundColor: isDarkMode ? "#4a5568" : "white",
      color: isDarkMode ? "#f7fafc" : "inherit"
    },
    select: {
      padding: "0.75rem",
      border: isDarkMode ? "2px solid #4a5568" : "2px solid #e0e0e0",
      borderRadius: "8px",
      fontSize: "1rem",
      backgroundColor: isDarkMode ? "#4a5568" : "white",
      color: isDarkMode ? "#f7fafc" : "inherit",
      cursor: "pointer",
      outline: "none"
    },
    button: {
      padding: "0.75rem 1.5rem",
      backgroundColor: "#3498db",
      color: "white",
      border: "none",
      borderRadius: "8px",
      fontSize: "1rem",
      fontWeight: "500",
      cursor: "pointer",
      transition: "background-color 0.3s ease",
      marginRight: "0.5rem"
    },
    buttonHover: {
      backgroundColor: "#2980b9"
    },
    deleteButton: {
      backgroundColor: "#e74c3c"
    },
    deleteButtonHover: {
      backgroundColor: "#c0392b"
    },
    editButton: {
      backgroundColor: "#f39c12"
    },
    editButtonHover: {
      backgroundColor: "#e67e22"
    },
    table: {
      width: "100%",
      backgroundColor: isDarkMode ? "#2d3748" : "white",
      borderRadius: "12px",
      overflow: "hidden",
      boxShadow: isDarkMode ? "0 4px 6px rgba(0, 0, 0, 0.3)" : "0 4px 6px rgba(0, 0, 0, 0.1)"
    },
    tableHeader: {
      backgroundColor: isDarkMode ? "#4a5568" : "#34495e",
      color: "white",
      fontWeight: "500",
      textAlign: "left" as const,
      padding: "1rem"
    },
    tableCell: {
      padding: "1rem",
      borderBottom: isDarkMode ? "1px solid #4a5568" : "1px solid #e0e0e0",
      color: isDarkMode ? "#e2e8f0" : "inherit"
    },
    tableRow: {
      transition: "background-color 0.3s ease",
      cursor: "pointer"
    },
    tableRowHover: {
      backgroundColor: isDarkMode ? "#4a5568" : "#f8f9fa"
    },
    editModal: {
      backgroundColor: isDarkMode ? "#2d3748" : "white",
      padding: "2rem",
      borderRadius: "12px",
      boxShadow: isDarkMode ? "0 8px 16px rgba(0, 0, 0, 0.4)" : "0 8px 16px rgba(0, 0, 0, 0.2)",
      marginTop: "2rem",
      border: isDarkMode ? "2px solid #4a5568" : "2px solid #3498db"
    },
    editTitle: {
      color: isDarkMode ? "#f7fafc" : "#2c3e50",
      fontSize: "1.5rem",
      marginBottom: "1.5rem",
      fontWeight: "500"
    },
    cancelButton: {
      backgroundColor: "#95a5a6"
    },
    cancelButtonHover: {
      backgroundColor: "#7f8c8d"
    },
    roleBadge: (role: string) => {
      let backgroundColor = isDarkMode ? "#2c5282" : "#3498db"; // alapértelmezett (viewer)
      let displayName = "Viewer";
      
      if (role === "admin") {
        backgroundColor = isDarkMode ? "#9b2c2c" : "#e74c3c";
        displayName = "Admin";
      } else if (role === "owner") {
        backgroundColor = isDarkMode ? "#553c9a" : "#9b59b6";
        displayName = "Tulajdonos";
      }
      
      return {
        padding: "0.25rem 0.75rem",
        borderRadius: "20px",
        fontSize: "0.875rem",
        fontWeight: "500",
        backgroundColor: backgroundColor,
        color: "white",
        display: "inline-block"
      };
    }
  };

  async function loadUsers() {
    try {
      const res = await fetch("http://localhost:4000/api/admin/users", {
        headers: {
          Authorization: "Bearer " + token
        }
      });

      if (!res.ok) {
        console.log("Backend hiba:", res.status);
        setUsers([]);
        return;
      }

      const data = await res.json();

      if (Array.isArray(data)) {
        setUsers(data);
      } else {
        setUsers([]);
      }
    } catch (err) {
      console.log("Fetch hiba:", err);
      setUsers([]);
    }
  }

  useEffect(() => {
    loadUsers();
  }, []);

  async function createUser(e: any) {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:4000/api/admin/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token
        },
        body: JSON.stringify(form)
      });

      if (!res.ok) {
        console.log("User létrehozás hiba:", res.status);
        return;
      }

      setForm({
        username: "",
        email: "",
        password: "",
        role: "viewer"
      });

      loadUsers();
    } catch (err) {
      console.log("Create user fetch hiba:", err);
    }
  }

  async function deleteUser(id: number) {
    if (!confirm("Biztos törlöd a felhasználót?")) return;

    try {
      const res = await fetch(`http://localhost:4000/api/admin/users/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: "Bearer " + token
        }
      });

      if (res.ok) {
        loadUsers();
      }
    } catch (err) {
      console.log("Delete hiba:", err);
    }
  }

  async function saveUser() {
    if (!editingUser) return;

    try {
      const res = await fetch(`http://localhost:4000/api/admin/users/${editingUser.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token
        },
        body: JSON.stringify(editingUser)
      });

      if (res.ok) {
        setEditingUser(null);
        loadUsers();
      }
    } catch (err) {
      console.log("Update hiba:", err);
    }
  }

  const getRoleDisplayName = (role: string) => {
    switch(role) {
      case "admin": return "Admin";
      case "owner": return "Tulajdonos";
      default: return "Viewer";
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Felhasználók kezelése</h1>

      <div style={styles.formContainer}>
        <h2 style={styles.formTitle}>Új felhasználó létrehozása</h2>
        <form onSubmit={createUser}>
          <div style={styles.inputGroup}>
            <input
              style={styles.input}
              placeholder="Felhasználónév"
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
              onFocus={(e) => e.target.style.borderColor = "#3498db"}
              onBlur={(e) => e.target.style.borderColor = isDarkMode ? "#4a5568" : "#e0e0e0"}
            />
            <input
              style={styles.input}
              placeholder="Email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              onFocus={(e) => e.target.style.borderColor = "#3498db"}
              onBlur={(e) => e.target.style.borderColor = isDarkMode ? "#4a5568" : "#e0e0e0"}
            />
            <input
              style={styles.input}
              type="password"
              placeholder="Jelszó"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              onFocus={(e) => e.target.style.borderColor = "#3498db"}
              onBlur={(e) => e.target.style.borderColor = isDarkMode ? "#4a5568" : "#e0e0e0"}
            />
            <select
              style={styles.select}
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value as "viewer" | "admin" | "owner" })}
              onFocus={(e) => e.target.style.borderColor = "#3498db"}
              onBlur={(e) => e.target.style.borderColor = isDarkMode ? "#4a5568" : "#e0e0e0"}
            >
              <option value="viewer">Viewer</option>
              <option value="admin">Admin</option>
              <option value="owner">Tulajdonos</option>
            </select>
          </div>
          <button
            type="submit"
            style={styles.button}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#2980b9"}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#3498db"}
          >
            Felhasználó létrehozása
          </button>
        </form>
      </div>

      <h2 style={{...styles.formTitle, marginTop: "2rem"}}>Felhasználók listája</h2>

      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.tableHeader}>ID</th>
            <th style={styles.tableHeader}>Név</th>
            <th style={styles.tableHeader}>Email</th>
            <th style={styles.tableHeader}>Role</th>
            <th style={styles.tableHeader}>Műveletek</th>
          </tr>
        </thead>
        <tbody>
          {Array.isArray(users) && users.map((u) => (
            <tr
              key={u.id}
              style={styles.tableRow}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = isDarkMode ? "#4a5568" : "#f8f9fa"}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "transparent"}
            >
              <td style={styles.tableCell}>{u.id}</td>
              <td style={styles.tableCell}>{u.username}</td>
              <td style={styles.tableCell}>{u.email}</td>
              <td style={styles.tableCell}>
                <span style={styles.roleBadge(u.role)}>
                  {getRoleDisplayName(u.role)}
                </span>
              </td>
              <td style={styles.tableCell}>
                <button
                  style={{...styles.button, ...styles.editButton}}
                  onClick={() => setEditingUser(u)}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#e67e22"}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#f39c12"}
                >
                  Szerkesztés
                </button>
                <button
                  style={{...styles.button, ...styles.deleteButton}}
                  onClick={() => deleteUser(u.id)}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#c0392b"}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#e74c3c"}
                >
                  Törlés
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editingUser && (
        <div style={styles.editModal}>
          <h3 style={styles.editTitle}>Felhasználó szerkesztése</h3>
          <div style={styles.inputGroup}>
            <input
              style={styles.input}
              value={editingUser.username}
              onChange={(e) =>
                setEditingUser({ ...editingUser, username: e.target.value })
              }
              onFocus={(e) => e.target.style.borderColor = "#3498db"}
              onBlur={(e) => e.target.style.borderColor = isDarkMode ? "#4a5568" : "#e0e0e0"}
            />
            <input
              style={styles.input}
              value={editingUser.email}
              onChange={(e) =>
                setEditingUser({ ...editingUser, email: e.target.value })
              }
              onFocus={(e) => e.target.style.borderColor = "#3498db"}
              onBlur={(e) => e.target.style.borderColor = isDarkMode ? "#4a5568" : "#e0e0e0"}
            />
            <select
              style={styles.select}
              value={editingUser.role}
              onChange={(e) =>
                setEditingUser({ ...editingUser, role: e.target.value as "viewer" | "admin" | "owner" })
              }
              onFocus={(e) => e.target.style.borderColor = "#3498db"}
              onBlur={(e) => e.target.style.borderColor = isDarkMode ? "#4a5568" : "#e0e0e0"}
            >
              <option value="viewer">Viewer</option>
              <option value="admin">Admin</option>
              <option value="owner">Tulajdonos</option>
            </select>
          </div>
          <div>
            <button
              style={styles.button}
              onClick={saveUser}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#2980b9"}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#3498db"}
            >
              Mentés
            </button>
            <button
              style={{...styles.button, ...styles.cancelButton}}
              onClick={() => setEditingUser(null)}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#7f8c8d"}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#95a5a6"}
            >
              Mégse
            </button>
          </div>
        </div>
      )}
    </div>
  );
}