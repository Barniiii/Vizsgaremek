import { useEffect, useState } from 'react';
import { 
  Plus, X, Mail, Phone, MapPin, Building2, 
  User, Calendar, Edit, Trash2, Search,
  Download, Upload, FileText, Globe, CreditCard
} from 'lucide-react';
import { getClients, addClient, deleteClient, updateClient } from '../db/operations';

interface Client {
  id: number;
  user_id: number;
  name: string;
  company_name?: string;
  tax_number?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  postal_code?: string;
  country?: string;
  contact_person?: string;
  website?: string;
  type?: string;
  payment_terms?: string;
  status: 'active' | 'inactive' | 'lead';
  notes?: string;
  last_contact?: string;
  created_at: string;
  updated_at?: string;
}

const Clients = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [filteredClients, setFilteredClients] = useState<Client[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    company_name: '',
    tax_number: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postal_code: '',
    country: 'Magyarország',
    contact_person: '',
    website: '',
    type: '',
    payment_terms: '',
    status: 'active' as 'active' | 'inactive' | 'lead',
    notes: '',
    last_contact: '',
  });

 const loadClients = async () => {
  const data = await getClients();
  console.log('loadClients - betöltött adatok:', data); // <-- Nézd meg mit ír ki!
  if (Array.isArray(data)) {
    setClients(data);
    setFilteredClients(data);
  } else {
    console.error('loadClients - nem tömb a data:', data);
    setClients([]);
    setFilteredClients([]);
  }
};

  useEffect(() => {
    loadClients();
  }, []);

  useEffect(() => {
    // Szűrés és keresés
    let filtered = clients;
    
    // Keresés
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(client => 
        client.name?.toLowerCase().includes(term) ||
        client.company_name?.toLowerCase().includes(term) ||
        client.email?.toLowerCase().includes(term) ||
        client.phone?.toLowerCase().includes(term) ||
        client.contact_person?.toLowerCase().includes(term) ||
        client.city?.toLowerCase().includes(term)
      );
    }
    
    // Típus szűrő
    if (filterType !== 'all') {
      filtered = filtered.filter(client => client.type === filterType);
    }
    
    // Státusz szűrő
    if (filterStatus !== 'all') {
      filtered = filtered.filter(client => client.status === filterStatus);
    }
    
    setFilteredClients(filtered);
  }, [searchTerm, filterType, filterStatus, clients]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Üres stringek konvertálása null-ra
    const processedData: any = {};
    Object.entries(formData).forEach(([key, value]) => {
      // Ha az érték üres string, akkor null-t küldünk
      if (value === '') {
        processedData[key] = null;
      } else {
        processedData[key] = value;
      }
    });
    
    // Alapértelmezett értékek beállítása (csak akkor, ha nincs érték)
    const clientData = {
      ...processedData,
      status: processedData.status || 'active',
      country: processedData.country || 'Magyarország',
      last_contact: processedData.last_contact || new Date().toISOString().split('T')[0]
    };
    
    console.log('Submitting client data:', clientData); // Debug
    
    try {
      if (editingClient) {
        await updateClient(editingClient.id, clientData);
      } else {
        await addClient(clientData);
      }
      
      // Form reset
      setFormData({
        name: '',
        company_name: '',
        tax_number: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        postal_code: '',
        country: 'Magyarország',
        contact_person: '',
        website: '',
        type: '',
        payment_terms: '',
        status: 'active',
        notes: '',
        last_contact: '',
      });
      
      setEditingClient(null);
      setShowForm(false);
      await loadClients();
    } catch (error) {
      console.error('Error saving client:', error);
      alert('Hiba történt a mentés során!');
    }
  };

  const handleEdit = (client: Client) => {
    setEditingClient(client);
    setFormData({
      name: client.name || '',
      company_name: client.company_name || '',
      tax_number: client.tax_number || '',
      email: client.email || '',
      phone: client.phone || '',
      address: client.address || '',
      city: client.city || '',
      postal_code: client.postal_code || '',
      country: client.country || 'Magyarország',
      contact_person: client.contact_person || '',
      website: client.website || '',
      type: client.type || '',
      payment_terms: client.payment_terms || '',
      status: client.status || 'active',
      notes: client.notes || '',
      last_contact: client.last_contact || '',
    });
    setShowForm(true);
  };

const handleDelete = async (id: number) => {
  console.log('handleDelete meghívva, ID:', id, 'Típus:', typeof id);
  try {
    const result = await deleteClient(id);
    console.log('deleteClient eredmény:', result);
    
    if (result && result.success === true) {
      console.log('Sikeres törlés');
      setShowDeleteConfirm(null);
      await loadClients();
    } else {
      throw new Error('Sikertelen törlés');
    }
  } catch (error) {
    console.error('Error deleting client:', error);
    alert('Hiba történt a törlés során: ' + (error instanceof Error ? error.message : 'Ismeretlen hiba'));
  }
};

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'active':
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Aktív</span>;
      case 'inactive':
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs">Inaktív</span>;
      case 'lead':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">Lehetőség</span>;
      default:
        return null;
    }
  };

  const getTypeBadge = (type: string) => {
    switch(type) {
      case 'felvásárló':
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">Felvásárló</span>;
      case 'partner':
        return <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs">Partner</span>;
      case 'egyéb':
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs">Egyéb</span>;
      default:
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs">-</span>;
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Ügyfelek / Partnerek</h1>
        <div className="flex flex-wrap gap-3">
          <button className="flex items-center gap-2 bg-white border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg transition-colors">
            <Download size={20} />
            Exportálás
          </button>
          <button className="flex items-center gap-2 bg-white border border-blue-600 text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-lg transition-colors">
            <Upload size={20} />
            Importálás
          </button>
          <button className="flex items-center gap-2 bg-white border border-purple-600 text-purple-600 hover:bg-purple-50 px-4 py-2 rounded-lg transition-colors">
            <Mail size={20} />
            Kör-email
          </button>
          <button
            onClick={() => {
              setEditingClient(null);
              setFormData({
                name: '',
                company_name: '',
                tax_number: '',
                email: '',
                phone: '',
                address: '',
                city: '',
                postal_code: '',
                country: 'Magyarország',
                contact_person: '',
                website: '',
                type: '',
                payment_terms: '',
                status: 'active',
                notes: '',
                last_contact: '',
              });
              setShowForm(true);
            }}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            <Plus size={20} />
            Új ügyfél
          </button>
        </div>
      </div>

      {/* Szűrők és kereső */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Keresés név, email, telefon, város alapján..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
          <div className="flex gap-4">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="all">Minden típus</option>
              <option value="felvásárló">Felvásárló</option>
              <option value="partner">Partner</option>
              <option value="egyéb">Egyéb</option>
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="all">Minden státusz</option>
              <option value="active">Aktív</option>
              <option value="inactive">Inaktív</option>
              <option value="lead">Lehetőség</option>
            </select>
          </div>
        </div>
      </div>

      {/* Űrlap modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl my-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">
                {editingClient ? 'Ügyfél szerkesztése' : 'Új ügyfél hozzáadása'}
              </h2>
              <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Alapadatok */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-700 border-b pb-2">Alapadatok</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Kapcsolattartó neve * <span className="text-gray-400 text-xs">(magánszemély neve)</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Pl. Kovács János"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Cégnév <span className="text-gray-400 text-xs">(ha cég)</span>
                    </label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="text"
                        value={formData.company_name}
                        onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Kft., Bt., Zrt. stb."
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Adószám</label>
                    <input
                      type="text"
                      value={formData.tax_number}
                      onChange={(e) => setFormData({ ...formData, tax_number: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="12345678-1-12"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Típus</label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    >
                      <option value="">Válassz...</option>
                      <option value="felvásárló">Felvásárló</option>
                      <option value="partner">Partner (beszállító, szolgáltató)</option>
                      <option value="egyéb">Egyéb</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Státusz</label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as 'active' | 'inactive' | 'lead' })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    >
                      <option value="active">Aktív</option>
                      <option value="inactive">Inaktív</option>
                      <option value="lead">Lehetőség (potenciális)</option>
                    </select>
                  </div>
                </div>

                {/* Elérhetőség */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-700 border-b pb-2">Elérhetőség</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="pelda@email.hu"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="+36 30 123 4567"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Weboldal</label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="url"
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="https://..."
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Fizetési feltételek</label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="text"
                        value={formData.payment_terms}
                        onChange={(e) => setFormData({ ...formData, payment_terms: e.target.value })}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="30 nap, készpénz, átutalás..."
                      />
                    </div>
                  </div>
                </div>

                {/* Cím adatok */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-700 border-b pb-2">Cím</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Ország</label>
                    <input
                      type="text"
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-1">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Irányítószám</label>
                      <input
                        type="text"
                        value={formData.postal_code}
                        onChange={(e) => setFormData({ ...formData, postal_code: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="1234"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Város</label>
                      <input
                        type="text"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Budapest"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Cím</label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 text-gray-400" size={18} />
                      <textarea
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        rows={2}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Utca, házszám..."
                      />
                    </div>
                  </div>
                </div>

                {/* Egyéb adatok */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-700 border-b pb-2">Egyéb információk</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Utolsó kapcsolatfelvétel</label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="date"
                        value={formData.last_contact}
                        onChange={(e) => setFormData({ ...formData, last_contact: e.target.value })}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Megjegyzések</label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-3 text-gray-400" size={18} />
                      <textarea
                        value={formData.notes}
                        onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                        rows={4}
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Fontos megjegyzések, megállapodások..."
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  {editingClient ? 'Módosítások mentése' : 'Mentés'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
                >
                  Mégse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Törlés megerősítés modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Törlés megerősítése</h2>
            <p className="text-gray-600 mb-6">Biztosan törölni szeretnéd ezt az ügyfelet? Ez a művelet nem visszavonható.</p>
            <div className="flex gap-3">
              <button
  onClick={() => {
    console.log('Törlés gomb megnyomva, ID:', showDeleteConfirm);
    if (showDeleteConfirm) {
      handleDelete(showDeleteConfirm);
    } else {
      console.error('Nincs törlendő ID!');
    }
  }}
  className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
>
  Törlés
</button>
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
              >
                Mégse
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Ügyfelek listája */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-green-50 border-b border-green-100">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Név / Cég</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Elérhetőség</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Cím</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Típus</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Státusz</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Utolsó kontakt</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-700">Műveletek</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredClients.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-8 text-center text-gray-500">
                    {clients.length === 0 
                      ? 'Még nincsenek ügyfelek rögzítve' 
                      : 'Nincs találat a keresési feltételeknek megfelelően'}
                  </td>
                </tr>
              ) : (
                filteredClients.map((client) => (
                  <tr key={client.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{client.name}</div>
                      {client.company_name && (
                        <div className="text-sm text-gray-500">{client.company_name}</div>
                      )}
                      {client.tax_number && (
                        <div className="text-xs text-gray-400">Adószám: {client.tax_number}</div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {client.email && (
                        <div className="flex items-center gap-1 text-sm">
                          <Mail size={14} className="text-gray-400" />
                          <a href={`mailto:${client.email}`} className="text-blue-600 hover:underline">
                            {client.email}
                          </a>
                        </div>
                      )}
                      {client.phone && (
                        <div className="flex items-center gap-1 text-sm mt-1">
                          <Phone size={14} className="text-gray-400" />
                          <a href={`tel:${client.phone}`} className="text-gray-600">
                            {client.phone}
                          </a>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {client.city && (
                        <div className="text-sm text-gray-600">
                          {client.postal_code && `${client.postal_code} `}
                          {client.city}
                        </div>
                      )}
                      {client.country && client.country !== 'Magyarország' && (
                        <div className="text-xs text-gray-400">{client.country}</div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {getTypeBadge(client.type || '')}
                    </td>
                    <td className="px-6 py-4">
                      {getStatusBadge(client.status)}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {client.last_contact 
                        ? new Date(client.last_contact).toLocaleDateString('hu-HU')
                        : '-'
                      }
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleEdit(client)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Szerkesztés"
                        >
                          <Edit size={18} />
                        </button>
                        <button
                          onClick={() => setShowDeleteConfirm(client.id)}
                          className="p-1 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Törlés"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Clients;