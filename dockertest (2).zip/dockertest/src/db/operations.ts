import { apiRequest } from '../api/http';

// NOTE: old local sql.js DB was replaced by API calls.
// The pages still import these helpers, so we keep the same function names.

// Típusok az API válaszokhoz
interface ApiResponse<T = any> {
  success?: boolean;
  item?: T;
  items?: T[];
  error?: string;
}

// DELETE műveletekhez specifikus típus
interface DeleteResponse {
  success: boolean;
}

function getToken(): string | null {
  return localStorage.getItem('bbagrar_token');
}

export const getAnimalCount = async () => {
  const token = getToken();
  const data = await apiRequest<{ animalCount: number }>('/api/dashboard/stats', { token });
  return data.animalCount;
};

export const getBalance = async () => {
  const token = getToken();
  const data = await apiRequest<{ balance: number }>('/api/dashboard/stats', { token });
  return data.balance;
};

export const getAnimals = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/animals', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching animals:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addAnimal = async (
  animal: { 
    name?: string; 
    species: string; 
    breed?: string; 
    identifier: string; 
    birth_date?: string;  // YYYY-MM-DD formátum
    stable?: string; 
    notes?: string 
  }
) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/animals', { 
      method: 'POST', 
      token, 
      body: animal 
    });
    return response;
  } catch (error) {
    console.error('Error adding animal:', error);
    throw error;
  }
};

export const deleteAnimal = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest<DeleteResponse>(`/api/animals/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting animal:', error);
    throw error;
  }
};

// Lands
export const getLands = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/lands', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching lands:', error);
    return [];
  }
};

export const deleteLand = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest<DeleteResponse>(`/api/lands/${id}`, { 
      method: 'DELETE', 
      token 
    });
    
    // Ha a response üres vagy csak { success: true } jön vissza
    return response || { success: true };
  } catch (error) {
    console.error('Error deleting land:', error);
    // Dobd tovább a hibát, hogy a komponens is kezelni tudja
    throw error;
  }
};

export const addLand = async (land: { 
  name: string; 
  plot_number?: string; 
  area: number;
  city?: string;
  ownership_type: 'owned' | 'rented';
  status?: string;
  notes?: string;
}) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/lands', { 
      method: 'POST', 
      token, 
      body: land 
    });
    return response;
  } catch (error) {
    console.error('Error adding land:', error);
    throw error;
  }
};

export const getExpenses = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/expenses', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching expenses:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addExpense = async (expense: { amount: number; category: string; description?: string; date: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/expenses', { 
      method: 'POST', 
      token, 
      body: expense 
    });
    return response;
  } catch (error) {
    console.error('Error adding expense:', error);
    throw error;
  }
};

export const deleteExpense = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest<DeleteResponse>(`/api/expenses/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting expense:', error);
    throw error;
  }
};

export const getIncomes = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/incomes', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching incomes:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addIncome = async (income: { amount: number; category: string; description?: string; date: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/incomes', { 
      method: 'POST', 
      token, 
      body: income 
    });
    return response;
  } catch (error) {
    console.error('Error adding income:', error);
    throw error;
  }
};

export const deleteIncome = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest<DeleteResponse>(`/api/incomes/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting income:', error);
    throw error;
  }
};

// Clients függvények
// Clients függvények - JAVÍTVA
export const getClients = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<any>('/api/clients', { token });
    console.log('getClients - API válasz:', data); // Debug
    
    // Az API { items: [...] } formátumban adja vissza
    if (data && data.items && Array.isArray(data.items)) {
      // Ellenőrizzük, hogy minden elemnek van-e id-ja
      const validItems = data.items.filter((item: any) => item && item.id);
      if (validItems.length !== data.items.length) {
        console.warn('getClients - néhány elemnek nincs id-ja:', data.items);
      }
      return validItems;
    } else if (Array.isArray(data)) {
      // Ha közvetlenül tömböt kapunk
      const validItems = data.filter((item: any) => item && item.id);
      return validItems;
    } else {
      console.warn('getClients - váratlan formátum:', data);
      return [];
    }
  } catch (error) {
    console.error('Error fetching clients:', error);
    return [];
  }
};

export const addClient = async (client: { 
  name: string; 
  company_name?: string | null;
  tax_number?: string | null;
  email?: string | null; 
  phone?: string | null; 
  address?: string | null;
  city?: string | null;
  postal_code?: string | null;
  country?: string | null;
  contact_person?: string | null;
  website?: string | null;
  type?: string | null; 
  payment_terms?: string | null;
  status?: 'active' | 'inactive' | 'lead';
  notes?: string | null;
  last_contact?: string | null;
}) => {
  const token = getToken();
  try {
    // Alapértelmezett értékek beállítása
    const clientData = {
      name: client.name,
      company_name: client.company_name || null,
      tax_number: client.tax_number || null,
      email: client.email || null,
      phone: client.phone || null,
      address: client.address || null,
      city: client.city || null,
      postal_code: client.postal_code || null,
      country: client.country || 'Magyarország',
      contact_person: client.contact_person || null,
      website: client.website || null,
      type: client.type || null,
      payment_terms: client.payment_terms || null,
      status: client.status || 'active',
      notes: client.notes || null,
      last_contact: client.last_contact || null
    };

    console.log('Sending client data:', clientData); // Debug célból
    
    const response = await apiRequest('/api/clients', { 
      method: 'POST', 
      token, 
      body: clientData 
    });
    return response;
  } catch (error) {
    console.error('Error adding client:', error);
    throw error;
  }
};

export const updateClient = async (id: number, client: {
  name: string; 
  company_name?: string | null;
  tax_number?: string | null;
  email?: string | null; 
  phone?: string | null; 
  address?: string | null;
  city?: string | null;
  postal_code?: string | null;
  country?: string | null;
  contact_person?: string | null;
  website?: string | null;
  type?: string | null; 
  payment_terms?: string | null;
  status?: 'active' | 'inactive' | 'lead';
  notes?: string | null;
  last_contact?: string | null;
}) => {
  const token = getToken();
  try {
    const clientData = {
      name: client.name,
      company_name: client.company_name || null,
      tax_number: client.tax_number || null,
      email: client.email || null,
      phone: client.phone || null,
      address: client.address || null,
      city: client.city || null,
      postal_code: client.postal_code || null,
      country: client.country || 'Magyarország',
      contact_person: client.contact_person || null,
      website: client.website || null,
      type: client.type || null,
      payment_terms: client.payment_terms || null,
      status: client.status || 'active',
      notes: client.notes || null,
      last_contact: client.last_contact || null
    };

    console.log('Updating client data:', clientData); // Debug célból
    
    const response = await apiRequest(`/api/clients/${id}`, { 
      method: 'PUT', 
      token, 
      body: clientData 
    });
    return response;
  } catch (error) {
    console.error('Error updating client:', error);
    throw error;
  }
};

export const deleteClient = async (id: number): Promise<DeleteResponse> => {
  console.log('deleteClient hívva, ID:', id);
  const token = getToken();
  try {
    const response = await apiRequest<DeleteResponse>(`/api/clients/${id}`, { 
      method: 'DELETE', 
      token 
    });
    console.log('deleteClient válasz:', response);
    
    // Ellenőrizzük, hogy sikeres-e a törlés
    if (response && response.success === true) {
      return response;
    } else {
      throw new Error('Sikertelen törlés');
    }
  } catch (error) {
    console.error('Error deleting client:', error);
    throw error;
  }
};

export const getMarketplace = async () => {
  try {
    const data = await apiRequest<{ items: any[] }>('/api/marketplace');
    return data.items;
  } catch (error) {
    console.error('Error fetching marketplace items:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addMarketplaceItem = async (item: { title: string; description?: string; type: string; price: number; image_url?: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/marketplace', { 
      method: 'POST', 
      token, 
      body: item 
    });
    return response;
  } catch (error) {
    console.error('Error adding marketplace item:', error);
    throw error;
  }
};

export const deleteMarketplaceItem = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest<DeleteResponse>(`/api/marketplace/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting marketplace item:', error);
    throw error;
  }
};

export const getDocuments = async () => {
  const token = getToken();
  try {
    const data = await apiRequest<{ items: any[] }>('/api/documents', { token });
    return data.items;
  } catch (error) {
    console.error('Error fetching documents:', error);
    return [];
  }
};

// Módosított függvény - csak 1 paraméter
export const addDocument = async (doc: { title: string; category: string; filename: string; filepath: string }) => {
  const token = getToken();
  try {
    const response = await apiRequest('/api/documents', { 
      method: 'POST', 
      token, 
      body: doc 
    });
    return response;
  } catch (error) {
    console.error('Error adding document:', error);
    throw error;
  }
};

export const deleteDocument = async (id: number) => {
  const token = getToken();
  try {
    const response = await apiRequest<DeleteResponse>(`/api/documents/${id}`, { 
      method: 'DELETE', 
      token 
    });
    return response;
  } catch (error) {
    console.error('Error deleting document:', error);
    throw error;
  }
};